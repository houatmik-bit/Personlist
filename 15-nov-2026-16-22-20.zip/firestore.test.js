const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_khaled";
const ADMIN_EMAIL = "khaledhouatmi17@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function nowTimestamp() {
  return new Date(Date.now() - 1000);
}

function buildQuotePayload({
  text = "ما لم يترك أثراً جميلاً في القلوب لا يُعدّ عمراً.",
  authorName = "جبران خليل جبران",
  topic = "حكمة",
  isAuthorVerified = true,
  isOwnerQuote = false,
  status = "pending",
  submittedByUid = ALICE_UID,
  submittedByName = "أليس",
  likesCount = 0,
  commentsCount = 0,
} = {}) {
  const ts = nowTimestamp();
  return {
    text,
    authorName,
    topic,
    isAuthorVerified,
    isOwnerQuote,
    status,
    submittedByUid,
    submittedByName,
    likesCount,
    commentsCount,
    createdAt: ts,
    updatedAt: ts,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write quotes", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("quotes").where("status", "==", "approved").get());
  await assertFails(unauthDb.collection("quotes").doc("q1").set(buildQuotePayload()));
});

test("Authenticated visitor can submit pending quote and query approved quotes", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("quotes").doc("q_approved").set(
      buildQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        submittedByUid: ADMIN_UID,
        submittedByName: "خالد",
      })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();

  // Visitor submits pending quote
  await assertSucceeds(
    aliceDb.collection("quotes").doc("q_pending_1").set(buildQuotePayload())
  );

  // Filtered query for approved quotes succeeds
  await assertSucceeds(
    aliceDb.collection("quotes").where("status", "==", "approved").get()
  );

  // Unfiltered list query fails (rules are not filters)
  await assertFails(aliceDb.collection("quotes").get());
});

test("Visitor cannot bypass review by submitting approved or owner quote or ghost fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();

  // Cannot create approved quote
  await assertFails(
    aliceDb.collection("quotes").doc("q_bad_status").set(buildQuotePayload({ status: "approved" }))
  );

  // Cannot claim isOwnerQuote = true
  await assertFails(
    aliceDb.collection("quotes").doc("q_bad_owner").set(buildQuotePayload({ isOwnerQuote: true }))
  );

  // Shadow Update / Ghost Field test
  const payloadWithGhost = { ...buildQuotePayload(), extraAdminFlag: true };
  await assertFails(
    aliceDb.collection("quotes").doc("q_ghost").set(payloadWithGhost)
  );
});

test("Email spoofing test: unverified admin email is rejected from admin actions", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  await assertFails(
    spoofDb.collection("quotes").doc("q_spoof").set(
      buildQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        submittedByUid: "spoof_uid",
      })
    )
  );
});

test("Verified admin can create owner quotes, approve pending quotes, and moderate reports", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();

  // Admin creates approved owner quote
  await assertSucceeds(
    adminDb.collection("quotes").doc("q_owner").set(
      buildQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        submittedByUid: ADMIN_UID,
        submittedByName: "خالد",
      })
    )
  );

  // Alice submits pending quote
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("quotes").doc("q_alice").set(buildQuotePayload()));

  // Bob cannot read Alice's pending quote
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("quotes").doc("q_alice").get());

  // Admin approves Alice's pending quote
  await assertSucceeds(
    adminDb.collection("quotes").doc("q_alice").update({
      status: "approved",
      updatedAt: nowTimestamp(),
    })
  );
});

test("Atomic like batch succeeds and isolated likesCount tampering fails", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("quotes").doc("q_like").set(
      buildQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        submittedByUid: ADMIN_UID,
      })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  // Tampering likesCount directly without likedQuotes doc fails
  await assertFails(
    aliceDb.collection("quotes").doc("q_like").update({
      likesCount: 1,
      updatedAt: nowTimestamp(),
    })
  );

  // Atomic batch creating likedQuotes doc + incrementing likesCount succeeds
  const batch = aliceDb.batch();
  batch.set(aliceDb.collection("users").doc(ALICE_UID).collection("likedQuotes").doc("q_like"), {
    quoteId: "q_like",
    userId: ALICE_UID,
    createdAt: nowTimestamp(),
  });
  batch.update(aliceDb.collection("quotes").doc("q_like"), {
    likesCount: 1,
    updatedAt: nowTimestamp(),
  });
  await assertSucceeds(batch.commit());
});

test("Cross-user isolation on favorites, comments, and reports", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("quotes").doc("q_pub").set(
      buildQuotePayload({
        status: "approved",
        isOwnerQuote: true,
        submittedByUid: ADMIN_UID,
      })
    );
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Alice adds favorite
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("favorites").doc("q_pub").set({
      quoteId: "q_pub",
      userId: ALICE_UID,
      text: "ما لم يترك أثراً جميلاً في القلوب لا يُعدّ عمراً.",
      authorName: "جبران خليل جبران",
      topic: "حكمة",
      createdAt: nowTimestamp(),
    })
  );

  // Bob cannot read or write Alice's favorites
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("favorites").get());

  // Alice creates a comment and a report
  await assertSucceeds(
    aliceDb.collection("quotes").doc("q_pub").collection("comments").doc("c1").set({
      quoteId: "q_pub",
      userId: ALICE_UID,
      userName: "أليس",
      text: "اقتباس رائع جداً",
      isPublic: true,
      createdAt: nowTimestamp(),
    })
  );

  // Bob cannot delete Alice's comment
  await assertFails(
    bobDb.collection("quotes").doc("q_pub").collection("comments").doc("c1").delete()
  );

  // Alice submits report
  await assertSucceeds(
    aliceDb.collection("reports").doc("r1").set({
      targetType: "quote",
      quoteId: "q_pub",
      targetSnippet: "ما لم يترك أثراً",
      reason: "محتوى غير مناسب",
      reporterUid: ALICE_UID,
      reporterName: "أليس",
      status: "open",
      createdAt: nowTimestamp(),
      updatedAt: nowTimestamp(),
    })
  );

  // Bob cannot read Alice's report
  await assertFails(bobDb.collection("reports").doc("r1").get());
  await assertFails(bobDb.collection("reports").get());
});

test("Original submitter can update and delete their own pending quote, without bypassing status or cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();

  const quoteRef = aliceDb.collection("quotes").doc("q_alice_edit");
  await assertSucceeds(quoteRef.set(buildQuotePayload()));

  // Submitter can update editable content fields while keeping status='pending'
  await assertSucceeds(
    quoteRef.update({
      text: "نص محدّث للاقتباس بانتظار المراجعة.",
      authorName: "محمود درويش",
      topic: "أدب",
      source: "ديوان محمود درويش",
      authorImageUrl: "https://upload.wikimedia.org/example.jpg",
      wikipediaUrl: "https://ar.wikipedia.org/wiki/محمود_درويش",
      isAuthorVerified: true,
      updatedAt: nowTimestamp(),
    })
  );

  // Submitter cannot self-approve their pending quote
  await assertFails(
    quoteRef.update({
      status: "approved",
      updatedAt: nowTimestamp(),
    })
  );

  // Another user cannot update or delete Alice's pending quote
  await assertFails(
    bobDb.collection("quotes").doc("q_alice_edit").update({
      text: "تعديل غير مصرح به",
      updatedAt: nowTimestamp(),
    })
  );
  await assertFails(bobDb.collection("quotes").doc("q_alice_edit").delete());

  // Submitter can delete their own pending quote
  await assertSucceeds(quoteRef.delete());
});

