package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArefRuqaaFontFamily

/**
 * Custom artistic logo for «أثر» where the letter Alif (أ) is shaped as
 * an Arabic calligraphy pen (Qalam) topped by a delicate butterfly.
 */
@Composable
fun AtharBrandLogo(
    modifier: Modifier = Modifier,
    penHeight: Dp = 42.dp,
    wordSize: TextUnit = 30.sp,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    goldAccent: Color = MaterialTheme.colorScheme.secondary,
    animateButterfly: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "butterfly_flutter")
    val wingFlap by if (animateButterfly) {
        infiniteTransition.animateFloat(
            initialValue = 0.88f,
            targetValue = 1.06f,
            animationSpec = infiniteRepeatable(
                animation = tween(1600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "wing_scale"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
    }

    Row(
        modifier = modifier.semantics { contentDescription = "شعار أثر" },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        // First in RTL is the right-most character: Alif (أ) as a Calligraphy Pen + Butterfly!
        Canvas(
            modifier = Modifier.size(width = penHeight * 0.65f, height = penHeight)
        ) {
            val w = size.width
            val h = size.height
            val cx = w * 0.50f

            // Butterfly perched gracefully above the Alif pen tip (replacing the Hamza!)
            val butterflyCenterY = h * 0.19f
            val wingSpread = w * 0.28f * wingFlap

            val leftWing = Path().apply {
                moveTo(cx, butterflyCenterY + h * 0.02f)
                cubicTo(
                    cx - wingSpread * 1.15f, butterflyCenterY - h * 0.14f,
                    cx - wingSpread * 1.25f, butterflyCenterY + h * 0.03f,
                    cx - wingSpread * 0.35f, butterflyCenterY + h * 0.08f
                )
                close()
            }
            val rightWing = Path().apply {
                moveTo(cx, butterflyCenterY + h * 0.02f)
                cubicTo(
                    cx + wingSpread * 1.15f, butterflyCenterY - h * 0.14f,
                    cx + wingSpread * 1.25f, butterflyCenterY + h * 0.03f,
                    cx + wingSpread * 0.35f, butterflyCenterY + h * 0.08f
                )
                close()
            }

            val wingBrush = Brush.linearGradient(
                colors = listOf(goldAccent, primaryColor),
                start = Offset(cx - wingSpread, butterflyCenterY - h * 0.10f),
                end = Offset(cx + wingSpread, butterflyCenterY + h * 0.10f)
            )
            drawPath(leftWing, brush = wingBrush)
            drawPath(rightWing, brush = wingBrush)

            // Delicate lower butterfly wings
            val lowerLeftWing = Path().apply {
                moveTo(cx, butterflyCenterY + h * 0.03f)
                cubicTo(
                    cx - wingSpread * 0.85f, butterflyCenterY + h * 0.05f,
                    cx - wingSpread * 0.70f, butterflyCenterY + h * 0.14f,
                    cx, butterflyCenterY + h * 0.08f
                )
                close()
            }
            val lowerRightWing = Path().apply {
                moveTo(cx, butterflyCenterY + h * 0.03f)
                cubicTo(
                    cx + wingSpread * 0.85f, butterflyCenterY + h * 0.05f,
                    cx + wingSpread * 0.70f, butterflyCenterY + h * 0.14f,
                    cx, butterflyCenterY + h * 0.08f
                )
                close()
            }
            drawPath(lowerLeftWing, color = goldAccent.copy(alpha = 0.85f))
            drawPath(lowerRightWing, color = goldAccent.copy(alpha = 0.85f))

            // Butterfly antennae
            drawLine(
                color = primaryColor,
                start = Offset(cx, butterflyCenterY),
                end = Offset(cx - w * 0.09f, butterflyCenterY - h * 0.08f),
                strokeWidth = 1.4f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = primaryColor,
                start = Offset(cx, butterflyCenterY),
                end = Offset(cx + w * 0.09f, butterflyCenterY - h * 0.08f),
                strokeWidth = 1.4f,
                cap = StrokeCap.Round
            )

            // Alif Calligraphy Reed Pen Body (vertical graceful stroke)
            val penTop = h * 0.30f
            val penBottom = h * 0.94f
            val penHalfWidth = w * 0.12f

            // Nib point at top pointing up toward the butterfly
            val nibPath = Path().apply {
                moveTo(cx, penTop)
                lineTo(cx + penHalfWidth * 1.15f, h * 0.44f)
                lineTo(cx - penHalfWidth * 1.15f, h * 0.44f)
                close()
            }
            drawPath(
                path = nibPath,
                brush = Brush.verticalGradient(
                    colors = listOf(goldAccent, primaryColor),
                    startY = penTop,
                    endY = h * 0.44f
                )
            )

            // Split ink channel inside the nib
            drawLine(
                color = Color.White.copy(alpha = 0.85f),
                start = Offset(cx, penTop + h * 0.02f),
                end = Offset(cx, h * 0.41f),
                strokeWidth = 1.5f,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.9f),
                radius = w * 0.028f,
                center = Offset(cx, h * 0.405f)
            )

            // Golden ferrule ring
            drawLine(
                color = goldAccent,
                start = Offset(cx - penHalfWidth * 1.2f, h * 0.46f),
                end = Offset(cx + penHalfWidth * 1.2f, h * 0.46f),
                strokeWidth = 2.6f,
                cap = StrokeCap.Round
            )

            // Alif calligraphic shaft tapering at the bottom
            val shaftPath = Path().apply {
                moveTo(cx - penHalfWidth, h * 0.485f)
                lineTo(cx + penHalfWidth, h * 0.485f)
                quadraticTo(
                    cx + penHalfWidth * 0.85f, h * 0.78f,
                    cx - penHalfWidth * 0.25f, penBottom
                )
                quadraticTo(
                    cx - penHalfWidth * 1.0f, h * 0.80f,
                    cx - penHalfWidth, h * 0.485f
                )
                close()
            }
            drawPath(
                path = shaftPath,
                brush = Brush.verticalGradient(
                    colors = listOf(primaryColor, primaryColor.copy(alpha = 0.85f), goldAccent),
                    startY = h * 0.485f,
                    endY = penBottom
                )
            )
        }

        // Remaining letters «ثر» in Aref Ruqaa seamlessly aligned in RTL
        Text(
            text = "ثر",
            fontFamily = ArefRuqaaFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = wordSize,
            color = primaryColor
        )
    }
}
