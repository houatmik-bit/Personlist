package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val AtharLightColorScheme = lightColorScheme(
    primary = BurgundyPrimary,
    onPrimary = Color.White,
    primaryContainer = BurgundyContainer,
    onPrimaryContainer = OnBurgundyContainer,
    secondary = AntiqueGoldSecondary,
    onSecondary = Color.White,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = OnGoldContainer,
    tertiary = EmeraldTertiary,
    onTertiary = Color.White,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = OnEmeraldContainer,
    background = CreamBackground,
    onBackground = EspressoInk,
    surface = CreamSurface,
    onSurface = EspressoInk,
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = WarmMutedInk,
    outline = CreamOutline,
    outlineVariant = Color(0xFFE9DEC9)
)

private val AtharDarkColorScheme = darkColorScheme(
    primary = LuminousGoldPrimary,
    onPrimary = Color(0xFF281C02),
    primaryContainer = DarkGoldContainer,
    onPrimaryContainer = OnDarkGoldContainer,
    secondary = RosewoodSecondary,
    onSecondary = Color(0xFF3E0A18),
    secondaryContainer = DarkRosewoodContainer,
    onSecondaryContainer = OnDarkRosewoodContainer,
    tertiary = MintEmeraldTertiary,
    onTertiary = Color(0xFF07261B),
    tertiaryContainer = DarkEmeraldContainer,
    onTertiaryContainer = OnDarkEmeraldContainer,
    background = DarkBackground,
    onBackground = WarmIvory,
    surface = DarkSurface,
    onSurface = WarmIvory,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkMutedIvory,
    outline = DarkOutline,
    outlineVariant = Color(0xFF352D38)
)

val AtharShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun AtharTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AtharDarkColorScheme else AtharLightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AtharTypography,
            shapes = AtharShapes,
            content = content
        )
    }
}
