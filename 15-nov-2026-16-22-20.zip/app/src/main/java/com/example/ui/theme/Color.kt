package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme — Warm Cream Parchment, Burgundy & Antique Gold
val CreamBackground = Color(0xFFFBF6EC)
val CreamSurface = Color(0xFFFFFDF8)
val CreamSurfaceVariant = Color(0xFFF2E8D5)
val CreamOutline = Color(0xFFDCCBB0)

val BurgundyPrimary = Color(0xFF7B1E32)
val BurgundyContainer = Color(0xFFF7DDE3)
val OnBurgundyContainer = Color(0xFF430A18)

val AntiqueGoldSecondary = Color(0xFFB88725)
val GoldContainer = Color(0xFFFAEDCA)
val OnGoldContainer = Color(0xFF3E2B04)

val EmeraldTertiary = Color(0xFF235C47)
val EmeraldContainer = Color(0xFFD5EFE4)
val OnEmeraldContainer = Color(0xFF0A2E21)

val EspressoInk = Color(0xFF241714)
val WarmMutedInk = Color(0xFF6B574E)

// Dark Theme — Deep Charcoal Obsidian, Luminous Gold & Rosewood
val DarkBackground = Color(0xFF131115)
val DarkSurface = Color(0xFF1D1A21)
val DarkSurfaceVariant = Color(0xFF2A242F)
val DarkOutline = Color(0xFF473D4A)

val LuminousGoldPrimary = Color(0xFFE3BA65)
val DarkGoldContainer = Color(0xFF4A3814)
val OnDarkGoldContainer = Color(0xFFFCE6B4)

val RosewoodSecondary = Color(0xFFE2849A)
val DarkRosewoodContainer = Color(0xFF541C2B)
val OnDarkRosewoodContainer = Color(0xFFFFD9E1)

val MintEmeraldTertiary = Color(0xFF6CD3AA)
val DarkEmeraldContainer = Color(0xFF153D2F)
val OnDarkEmeraldContainer = Color(0xFFC2F5E0)

val WarmIvory = Color(0xFFF5EEE2)
val DarkMutedIvory = Color(0xFFBBAE9E)
