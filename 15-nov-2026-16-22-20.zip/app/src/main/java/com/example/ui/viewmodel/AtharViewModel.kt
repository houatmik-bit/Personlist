package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminConfig
import com.example.data.model.AuthorWikiInfo
import com.example.data.model.FavoriteQuote
import com.example.data.model.Quote
import com.example.data.model.QuoteComment
import com.example.data.model.QuoteTopic
import com.example.data.model.Report
import com.example.data.model.ReportStatus
import com.example.data.remote.WikipediaRepository
import com.example.data.repository.AtharRepository
import com.example.data.repository.ThemePreferencesRepository
import com.example.data.seed.StarterQuotes
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

class AtharViewModel(
    private val repository: AtharRepository,
    private val wikipediaRepository: WikipediaRepository,
    private val themePreferences: ThemePreferencesRepository,
    val currentUserId: String,
    val currentUserEmail: String?,
    val currentUserName: String
) : ViewModel() {

    val isOwner: Boolean = currentUserEmail.equals(AdminConfig.OWNER_EMAIL, ignoreCase = true)

    val isDarkThemePref: StateFlow<Boolean?> = themePreferences.isDarkModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), null)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTopic = MutableStateFlow<QuoteTopic?>(null)
    val selectedTopic: StateFlow<QuoteTopic?> = _selectedTopic.asStateFlow()

    private val _authorWikiCache = MutableStateFlow<Map<String, AuthorWikiInfo>>(emptyMap())
    val authorWikiCache: StateFlow<Map<String, AuthorWikiInfo>> = _authorWikiCache.asStateFlow()

    private val _quoteOfTheDay = MutableStateFlow<Quote?>(null)
    val quoteOfTheDay: StateFlow<Quote?> = _quoteOfTheDay.asStateFlow()

    private val _authorPreview = MutableStateFlow<AuthorWikiInfo?>(null)
    val authorPreview: StateFlow<AuthorWikiInfo?> = _authorPreview.asStateFlow()

    private val _isLookingUpAuthor = MutableStateFlow(false)
    val isLookingUpAuthor: StateFlow<Boolean> = _isLookingUpAuthor.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private var lookupJob: Job? = null
    private var autoSeedAttempted = false

    val approvedQuotesState: StateFlow<UiState<List<Quote>>> = repository.observeApprovedQuotes()
        .map<List<Quote>, UiState<List<Quote>>> { quotes ->
            val enriched = quotes.map { q -> enrichQuoteWithCache(q) }
            UiState.Success(enriched)
        }
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observing approved quotes", root)
            emit(UiState.Error(root.message ?: "تعذر تحميل الاقتباسات"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val filteredQuotesState: StateFlow<UiState<List<Quote>>> = combine(
        approvedQuotesState,
        _searchQuery,
        _selectedTopic,
        _authorWikiCache
    ) { quotesState, query, topic, wikiMap ->
        when (quotesState) {
            is UiState.Loading -> UiState.Loading
            is UiState.Error -> quotesState
            is UiState.Success -> {
                val trimmed = query.trim()
                val filtered = quotesState.data
                    .map { q -> applyWikiMap(q, wikiMap) }
                    .filter { q ->
                        val topicMatches = topic == null || q.topic == topic.labelAr
                        val queryMatches = trimmed.isEmpty() ||
                            q.text.contains(trimmed, ignoreCase = true) ||
                            q.authorName.contains(trimmed, ignoreCase = true) ||
                            q.source.contains(trimmed, ignoreCase = true)
                        topicMatches && queryMatches
                    }
                UiState.Success(filtered)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    val favorites: StateFlow<List<FavoriteQuote>> = repository.observeFavorites(currentUserId)
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing favorites", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val favoriteIds: StateFlow<Set<String>> = favorites
        .map { list -> list.map { it.quoteId }.toSet() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptySet()
        )

    val likedQuoteIds: StateFlow<Set<String>> = repository.observeLikedQuoteIds(currentUserId)
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing liked quote IDs", firestoreError ?: error)
            emit(emptySet())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptySet()
        )

    val mySubmissions: StateFlow<List<Quote>> = repository.observeMySubmissions(currentUserId)
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing my submissions", firestoreError ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val pendingQuotes: StateFlow<List<Quote>> = if (isOwner) {
        repository.observePendingQuotes()
            .catch { error ->
                val firestoreError = unwrapFirestoreException(error)
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Error observing pending quotes", firestoreError ?: error)
                emit(emptyList())
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = emptyList()
            )
    } else {
        MutableStateFlow(emptyList())
    }

    val openReports: StateFlow<List<Report>> = if (isOwner) {
        repository.observeOpenReports()
            .catch { error ->
                val firestoreError = unwrapFirestoreException(error)
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Error observing open reports", firestoreError ?: error)
                emit(emptyList())
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = emptyList()
            )
    } else {
        MutableStateFlow(emptyList())
    }

    init {
        // Pick initial Quote of the Day & trigger Wikipedia photo enrichment
        viewModelScope.launch {
            approvedQuotesState.collect { state ->
                if (state is UiState.Success) {
                    val quotes = state.data
                    if (quotes.isEmpty() && isOwner && !autoSeedAttempted) {
                        autoSeedAttempted = true
                        repository.seedStarterOwnerQuotes(StarterQuotes.curatedOwnerQuotes)
                    } else if (quotes.isNotEmpty()) {
                        val currentQotd = _quoteOfTheDay.value
                        if (currentQotd == null || quotes.none { it.id == currentQotd.id }) {
                            _quoteOfTheDay.value = quotes.random()
                        } else {
                            quotes.firstOrNull { it.id == currentQotd.id }?.let { updated ->
                                _quoteOfTheDay.value = applyWikiMap(updated, _authorWikiCache.value)
                            }
                        }
                        prefetchAuthorsForQuotes(quotes)
                    }
                }
            }
        }
    }

    fun setDarkMode(isDark: Boolean) {
        viewModelScope.launch {
            themePreferences.setDarkMode(isDark)
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectTopic(topic: QuoteTopic?) {
        _selectedTopic.value = topic
    }

    fun shuffleQuoteOfTheDay() {
        val currentList = (approvedQuotesState.value as? UiState.Success)?.data ?: return
        if (currentList.isEmpty()) return
        val currentId = _quoteOfTheDay.value?.id
        val candidates = if (currentList.size > 1) currentList.filter { it.id != currentId } else currentList
        _quoteOfTheDay.value = applyWikiMap(candidates.random(), _authorWikiCache.value)
    }

    fun lookupAuthorPreview(authorName: String) {
        lookupJob?.cancel()
        val trimmed = authorName.trim()
        if (trimmed.length < 2) {
            _authorPreview.value = null
            _isLookingUpAuthor.value = false
            return
        }
        lookupJob = viewModelScope.launch {
            _isLookingUpAuthor.value = true
            delay(450L)
            val info = wikipediaRepository.fetchAuthorInfo(trimmed)
            _authorPreview.value = info
            _authorWikiCache.value = _authorWikiCache.value + (trimmed to info)
            _isLookingUpAuthor.value = false
        }
    }

    fun clearAuthorPreview() {
        _authorPreview.value = null
    }

    fun submitQuote(
        text: String,
        authorName: String,
        topic: QuoteTopic,
        source: String?,
        publishImmediatelyAsOwner: Boolean,
        onSuccess: (publishedDirectly: Boolean) -> Unit
    ) {
        viewModelScope.launch {
            val wikiInfo = _authorPreview.value?.takeIf {
                it.authorName.equals(authorName.trim(), ignoreCase = true)
            } ?: wikipediaRepository.fetchAuthorInfo(authorName.trim())

            val result = repository.submitQuote(
                text = text,
                authorName = authorName,
                topic = topic,
                source = source,
                authorImageUrl = wikiInfo.imageUrl,
                wikipediaUrl = wikiInfo.wikipediaUrl,
                isAuthorVerified = wikiInfo.isVerified,
                publishImmediatelyAsOwner = publishImmediatelyAsOwner
            )
            if (result.isSuccess) {
                val direct = publishImmediatelyAsOwner && isOwner
                _actionMessage.value = if (direct) {
                    "تم نشر الاقتباس في الصفحة الرئيسية بنجاح"
                } else {
                    "شكرًا لأثرك! تم إرسال الاقتباس وهو الآن قيد المراجعة"
                }
                _authorPreview.value = null
                onSuccess(direct)
            } else {
                _actionMessage.value = result.exceptionOrNull()?.localizedMessage ?: "تعذر حفظ الاقتباس"
            }
        }
    }

    fun toggleLike(quote: Quote) {
        val currentlyLiked = likedQuoteIds.value.contains(quote.id)
        viewModelScope.launch {
            val res = repository.toggleLike(quote, currentlyLiked)
            if (res.isFailure) {
                _actionMessage.value = "تعذر تحديث الإعجاب"
            }
        }
    }

    fun toggleFavorite(quote: Quote) {
        val currentlyFavorited = favoriteIds.value.contains(quote.id)
        viewModelScope.launch {
            val res = repository.toggleFavorite(quote, currentlyFavorited)
            if (res.isSuccess) {
                _actionMessage.value = if (currentlyFavorited) "أُزيل من المفضلة" else "تم الحفظ في المفضلة"
            } else {
                _actionMessage.value = "تعذر تحديث المفضلة"
            }
        }
    }

    fun observeQuoteDetail(quoteId: String): Flow<Quote?> = repository.observeQuoteById(quoteId)
        .map { q -> q?.let { applyWikiMap(it, _authorWikiCache.value) } }
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing quote $quoteId", firestoreError ?: error)
            emit(null)
        }

    fun observeComments(quoteId: String): Flow<List<QuoteComment>> = repository.observeComments(quoteId)
        .catch { error ->
            val firestoreError = unwrapFirestoreException(error)
            if (firestoreError == null && error is CancellationException) throw error
            Log.w(TAG, "Error observing comments for $quoteId", firestoreError ?: error)
            emit(emptyList())
        }

    fun addComment(quoteId: String, text: String, onDone: () -> Unit) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val res = repository.addComment(quoteId, text)
            if (res.isSuccess) {
                onDone()
            } else {
                _actionMessage.value = "تعذر إضافة التعليق"
            }
        }
    }

    fun deleteComment(quoteId: String, commentId: String, currentCount: Long) {
        viewModelScope.launch {
            val res = repository.deleteComment(quoteId, commentId, currentCount)
            if (res.isSuccess) {
                _actionMessage.value = "تم حذف التعليق"
            } else {
                _actionMessage.value = "تعذر حذف التعليق"
            }
        }
    }

    fun submitReport(
        targetType: String,
        quoteId: String,
        commentId: String? = null,
        targetSnippet: String,
        reason: String
    ) {
        viewModelScope.launch {
            val res = repository.submitReport(targetType, quoteId, commentId, targetSnippet, reason)
            _actionMessage.value = if (res.isSuccess) {
                "تم استلام بلاغك وسيتم مراجعته من قِبل الإدارة"
            } else {
                "تعذر إرسال البلاغ"
            }
        }
    }

    fun approvePendingQuote(quoteId: String) {
        viewModelScope.launch {
            val res = repository.approveQuote(quoteId)
            _actionMessage.value = if (res.isSuccess) "تمت الموافقة ونشر الاقتباس" else "تعذر اعتماد الاقتباس"
        }
    }

    fun rejectPendingQuote(quoteId: String) {
        viewModelScope.launch {
            val res = repository.rejectQuote(quoteId)
            _actionMessage.value = if (res.isSuccess) "تم رفض المساهمة" else "تعذر رفض المساهمة"
        }
    }

    fun deleteQuote(quoteId: String) {
        viewModelScope.launch {
            val res = repository.deleteQuote(quoteId)
            _actionMessage.value = if (res.isSuccess) "تم حذف الاقتباس" else "تعذر حذف الاقتباس"
        }
    }

    fun resolveReport(report: Report, deleteContent: Boolean) {
        viewModelScope.launch {
            if (deleteContent) {
                if (report.targetType == "comment" && report.commentId.isNotBlank()) {
                    repository.deleteComment(report.quoteId, report.commentId, 1L)
                } else {
                    repository.deleteQuote(report.quoteId)
                }
            }
            val newStatus = if (deleteContent) ReportStatus.RESOLVED else ReportStatus.DISMISSED
            val res = repository.updateReportStatus(report.id, newStatus)
            _actionMessage.value = if (res.isSuccess) {
                if (deleteContent) "تم حذف المحتوى وإغلاق البلاغ" else "تم تجاهل البلاغ"
            } else {
                "تعذر تحديث حالة البلاغ"
            }
        }
    }

    fun seedStarterQuotes() {
        viewModelScope.launch {
            val res = repository.seedStarterOwnerQuotes(StarterQuotes.curatedOwnerQuotes)
            _actionMessage.value = if (res.isSuccess) {
                val count = res.getOrDefault(0)
                if (count > 0) "تم نشر $count اقتباسات تأسيسية بنجاح" else "يوجد اقتباسات منشورة بالفعل"
            } else {
                "تعذر نشر المختارات التأسيسية"
            }
        }
    }

    fun clearMessage() {
        _actionMessage.value = null
    }

    private fun prefetchAuthorsForQuotes(quotes: List<Quote>) {
        val missingAuthors = quotes
            .filter { it.authorImageUrl.isBlank() }
            .map { it.authorName.trim() }
            .distinct()
            .filter { !_authorWikiCache.value.containsKey(it) }
            .take(10)

        if (missingAuthors.isEmpty()) return
        viewModelScope.launch {
            val updates = mutableMapOf<String, AuthorWikiInfo>()
            missingAuthors.forEach { name ->
                val info = wikipediaRepository.fetchAuthorInfo(name)
                updates[name] = info
                if (isOwner && (!info.imageUrl.isNullOrBlank() || !info.wikipediaUrl.isNullOrBlank())) {
                    quotes.filter { it.authorName.trim() == name && it.authorImageUrl.isBlank() }
                        .forEach { quote ->
                            repository.updateAuthorEnrichment(
                                quoteId = quote.id,
                                authorImageUrl = info.imageUrl,
                                wikipediaUrl = info.wikipediaUrl,
                                isAuthorVerified = info.isVerified
                            )
                        }
                }
            }
            if (updates.isNotEmpty()) {
                _authorWikiCache.value = _authorWikiCache.value + updates
            }
        }
    }

    private fun enrichQuoteWithCache(quote: Quote): Quote {
        return applyWikiMap(quote, _authorWikiCache.value)
    }

    private fun applyWikiMap(quote: Quote, wikiMap: Map<String, AuthorWikiInfo>): Quote {
        val info = wikiMap[quote.authorName.trim()] ?: return quote
        return quote.copy(
            authorImageUrl = quote.authorImageUrl.ifBlank { info.imageUrl.orEmpty() },
            wikipediaUrl = quote.wikipediaUrl.ifBlank { info.wikipediaUrl.orEmpty() },
            isAuthorVerified = quote.isAuthorVerified || info.isVerified
        )
    }

    private fun unwrapFirestoreException(error: Throwable): FirebaseFirestoreException? {
        return generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
    }

    private companion object {
        const val TAG = "AtharVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
