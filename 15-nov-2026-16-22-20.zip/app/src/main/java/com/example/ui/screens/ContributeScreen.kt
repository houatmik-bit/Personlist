package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.HourglassTop
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AuthorWikiInfo
import com.example.data.model.Quote
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteTopic
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.ArefRuqaaFontFamily
import com.example.ui.theme.CairoFontFamily

@Composable
fun ContributeScreen(
    authorPreview: AuthorWikiInfo?,
    isLookingUpAuthor: Boolean,
    mySubmissions: List<Quote>,
    onAuthorNameChanged: (String) -> Unit,
    onSubmitQuote: (
        text: String,
        authorName: String,
        topic: QuoteTopic,
        source: String?,
        onDone: () -> Unit
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var quoteText by remember { mutableStateOf("") }
    var authorName by remember { mutableStateOf("") }
    var sourceText by remember { mutableStateOf("") }
    var selectedTopic by remember { mutableStateOf(QuoteTopic.WISDOM) }
    var isSubmitting by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item(key = "contribute_header") {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Create,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column {
                                Text(
                                    text = "اترك أثرك",
                                    fontFamily = ArefRuqaaFontFamily,
                                    fontSize = 26.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "أضف اقتباساً ملهماً وسيُراجع من قِبل المالك قبل نشره للجميع",
                                    fontFamily = CairoFontFamily,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedTextField(
                            value = quoteText,
                            onValueChange = { quoteText = it },
                            label = { Text("نص الاقتباس", fontFamily = CairoFontFamily) },
                            placeholder = {
                                Text("اكتب الاقتباس هنا (5 أحرف على الأقل)…", fontFamily = CairoFontFamily)
                            },
                            minLines = 3,
                            maxLines = 6,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("contribute_quote_text_input")
                        )

                        OutlinedTextField(
                            value = authorName,
                            onValueChange = {
                                authorName = it
                                onAuthorNameChanged(it)
                            },
                            label = { Text("اسم القائل أو الكاتب", fontFamily = CairoFontFamily) },
                            placeholder = {
                                Text("مثال: جبران خليل جبران", fontFamily = CairoFontFamily)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("contribute_author_input")
                        )

                        // Live Wikipedia Author Verification Preview
                        if (isLookingUpAuthor || authorPreview != null) {
                            AuthorWikiPreviewCard(
                                info = authorPreview,
                                isLoading = isLookingUpAuthor
                            )
                        }

                        OutlinedTextField(
                            value = sourceText,
                            onValueChange = { sourceText = it },
                            label = { Text("المصدر أو الكتاب (اختياري)", fontFamily = CairoFontFamily) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("contribute_source_input")
                        )

                        Text(
                            text = "الموضوع",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QuoteTopic.entries.forEach { topic ->
                                FilterChip(
                                    selected = selectedTopic == topic,
                                    onClick = { selectedTopic = topic },
                                    label = {
                                        Text(
                                            text = topic.labelAr,
                                            fontFamily = CairoFontFamily,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    },
                                    shape = RoundedCornerShape(50)
                                )
                            }
                        }

                        val canSubmit = quoteText.trim().length >= 5 &&
                            authorName.trim().length >= 2 &&
                            !isSubmitting

                        Button(
                            onClick = {
                                isSubmitting = true
                                onSubmitQuote(
                                    quoteText,
                                    authorName,
                                    selectedTopic,
                                    sourceText.ifBlank { null }
                                ) {
                                    isSubmitting = false
                                    quoteText = ""
                                    authorName = ""
                                    sourceText = ""
                                }
                            },
                            enabled = canSubmit,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("submit_contribute_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Send,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "إرسال للمراجعة",
                                    fontFamily = CairoFontFamily,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            if (mySubmissions.isNotEmpty()) {
                item(key = "my_submissions_title") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.HourglassTop,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "مساهماتي (${mySubmissions.size})",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                }

                items(items = mySubmissions, key = { it.id }) { item ->
                    val (statusLabel, statusColor) = when (item.status) {
                        QuoteStatus.APPROVED -> "معتمد ومنشور" to Color(0xFF1F6E52)
                        QuoteStatus.REJECTED -> "مرفوض" to Color(0xFFB3261E)
                        else -> "قيد المراجعة" to Color(0xFFB88725)
                    }
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = statusColor.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = statusLabel,
                                        color = statusColor,
                                        fontFamily = CairoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = item.topic,
                                    fontFamily = CairoFontFamily,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "«${item.text}»",
                                fontFamily = AmiriFontFamily,
                                fontSize = 18.sp,
                                lineHeight = 30.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "— ${item.authorName}",
                                fontFamily = CairoFontFamily,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthorWikiPreviewCard(
    info: AuthorWikiInfo?,
    isLoading: Boolean
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                Text(
                    text = "جارٍ البحث عن معلومات الكاتب في ويكيبيديا…",
                    fontFamily = CairoFontFamily,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else if (info != null) {
                if (!info.imageUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = info.imageUrl,
                        contentDescription = info.authorName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (info.isVerified) "تم التوثيق عبر ويكيبيديا" else "كاتب غير موثق في ويكيبيديا",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (info.isVerified) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (info.isVerified) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    if (!info.description.isNullOrBlank()) {
                        Text(
                            text = info.description,
                            fontFamily = CairoFontFamily,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
