package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuthorWikiInfo
import com.example.data.model.Quote
import com.example.data.model.QuoteTopic
import com.example.data.model.Report
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.CairoFontFamily

@Composable
fun AdminDashboardScreen(
    pendingQuotes: List<Quote>,
    openReports: List<Report>,
    authorPreview: AuthorWikiInfo?,
    isLookingUpAuthor: Boolean,
    onAuthorNameChanged: (String) -> Unit,
    onPublishOwnerQuote: (
        text: String,
        authorName: String,
        topic: QuoteTopic,
        source: String?,
        onDone: () -> Unit
    ) -> Unit,
    onApproveQuote: (String) -> Unit,
    onRejectQuote: (String) -> Unit,
    onResolveReport: (Report, deleteContent: Boolean) -> Unit,
    onSeedStarterQuotes: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .align(Alignment.CenterHorizontally)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AdminPanelSettings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "لوحة تحكم المالك",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    OutlinedButton(
                        onClick = onSeedStarterQuotes,
                        modifier = Modifier.testTag("admin_seed_button")
                    ) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نشر المختارات", fontFamily = CairoFontFamily, fontSize = 12.sp)
                    }
                }

                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text("نشر اقتباس", fontFamily = CairoFontFamily, fontWeight = FontWeight.SemiBold)
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("المراجعة", fontFamily = CairoFontFamily, fontWeight = FontWeight.SemiBold)
                                if (pendingQuotes.isNotEmpty()) {
                                    Badge { Text(pendingQuotes.size.toString()) }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("البلاغات", fontFamily = CairoFontFamily, fontWeight = FontWeight.SemiBold)
                                if (openReports.isNotEmpty()) {
                                    Badge { Text(openReports.size.toString()) }
                                }
                            }
                        }
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            when (selectedTab) {
                0 -> AdminPublishQuoteTab(
                    authorPreview = authorPreview,
                    isLookingUpAuthor = isLookingUpAuthor,
                    onAuthorNameChanged = onAuthorNameChanged,
                    onPublishOwnerQuote = onPublishOwnerQuote
                )
                1 -> AdminPendingReviewTab(
                    pendingQuotes = pendingQuotes,
                    onApproveQuote = onApproveQuote,
                    onRejectQuote = onRejectQuote
                )
                2 -> AdminReportsTab(
                    reports = openReports,
                    onResolveReport = onResolveReport
                )
            }
        }
    }
}

@Composable
private fun AdminPublishQuoteTab(
    authorPreview: AuthorWikiInfo?,
    isLookingUpAuthor: Boolean,
    onAuthorNameChanged: (String) -> Unit,
    onPublishOwnerQuote: (String, String, QuoteTopic, String?, () -> Unit) -> Unit
) {
    var quoteText by remember { mutableStateOf("") }
    var authorName by remember { mutableStateOf("") }
    var sourceText by remember { mutableStateOf("") }
    var selectedTopic by remember { mutableStateOf(QuoteTopic.WISDOM) }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "إضافة اقتباس مباشر باسم المالك",
                        fontFamily = CairoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    OutlinedTextField(
                        value = quoteText,
                        onValueChange = { quoteText = it },
                        label = { Text("نص الاقتباس", fontFamily = CairoFontFamily) },
                        minLines = 3,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_quote_input")
                    )
                    OutlinedTextField(
                        value = authorName,
                        onValueChange = {
                            authorName = it
                            onAuthorNameChanged(it)
                        },
                        label = { Text("اسم الكاتب أو المفكر", fontFamily = CairoFontFamily) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_author_input")
                    )
                    if (isLookingUpAuthor || authorPreview != null) {
                        AuthorWikiPreviewCard(info = authorPreview, isLoading = isLookingUpAuthor)
                    }
                    OutlinedTextField(
                        value = sourceText,
                        onValueChange = { sourceText = it },
                        label = { Text("المصدر / الكتاب (اختياري)", fontFamily = CairoFontFamily) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuoteTopic.entries.forEach { topic ->
                            FilterChip(
                                selected = selectedTopic == topic,
                                onClick = { selectedTopic = topic },
                                label = { Text(topic.labelAr, fontFamily = CairoFontFamily) }
                            )
                        }
                    }
                    Button(
                        onClick = {
                            onPublishOwnerQuote(
                                quoteText,
                                authorName,
                                selectedTopic,
                                sourceText.ifBlank { null }
                            ) {
                                quoteText = ""
                                authorName = ""
                                sourceText = ""
                            }
                        },
                        enabled = quoteText.trim().length >= 5 && authorName.trim().length >= 2,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("admin_publish_button")
                    ) {
                        Icon(Icons.Outlined.AddCircleOutline, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("نشر الاقتباس فوراً", fontFamily = CairoFontFamily, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminPendingReviewTab(
    pendingQuotes: List<Quote>,
    onApproveQuote: (String) -> Unit,
    onRejectQuote: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (pendingQuotes.isEmpty()) {
            item {
                Text(
                    text = "لا توجد مساهمات بانتظار المراجعة حالياً.",
                    fontFamily = CairoFontFamily,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp)
                )
            }
        } else {
            items(items = pendingQuotes, key = { it.id }) { quote ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "مساهمة من: ${quote.submittedByName}  •  ${quote.topic}",
                            fontFamily = CairoFontFamily,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "«${quote.text}»",
                            fontFamily = AmiriFontFamily,
                            fontSize = 19.sp,
                            lineHeight = 31.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "— ${quote.authorName}",
                            fontFamily = CairoFontFamily,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onApproveQuote(quote.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F6E52)),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("approve_quote_${quote.id}")
                            ) {
                                Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("موافقة ونشر", fontFamily = CairoFontFamily)
                            }
                            OutlinedButton(
                                onClick = { onRejectQuote(quote.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("reject_quote_${quote.id}")
                            ) {
                                Icon(Icons.Outlined.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("رفض", fontFamily = CairoFontFamily)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminReportsTab(
    reports: List<Report>,
    onResolveReport: (Report, deleteContent: Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 720.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (reports.isEmpty()) {
            item {
                Text(
                    text = "لا توجد بلاغات مفتوحة حالياً.",
                    fontFamily = CairoFontFamily,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp)
                )
            }
        } else {
            items(items = reports, key = { it.id }) { report ->
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Flag,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = if (report.targetType == "comment") "بلاغ على تعليق" else "بلاغ على اقتباس",
                                fontFamily = CairoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "المُبلّغ: ${report.reporterName}  •  السبب: ${report.reason}",
                            fontFamily = CairoFontFamily,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = report.targetSnippet,
                                fontFamily = CairoFontFamily,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onResolveReport(report, true) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("delete_reported_${report.id}")
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حذف المحتوى", fontFamily = CairoFontFamily)
                            }
                            OutlinedButton(
                                onClick = { onResolveReport(report, false) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("dismiss_report_${report.id}")
                            ) {
                                Text("تجاهل البلاغ", fontFamily = CairoFontFamily)
                            }
                        }
                    }
                }
            }
        }
    }
}
