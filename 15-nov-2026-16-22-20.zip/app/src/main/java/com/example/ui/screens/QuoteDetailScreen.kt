package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Quote
import com.example.data.model.QuoteComment
import com.example.data.model.QuoteTopic
import com.example.ui.components.AdSlotBanner
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.ArefRuqaaFontFamily
import com.example.ui.theme.CairoFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteDetailScreen(
    quote: Quote?,
    comments: List<QuoteComment>,
    isLiked: Boolean,
    isFavorited: Boolean,
    currentUserId: String,
    isOwner: Boolean,
    isDarkTheme: Boolean,
    onBack: () -> Unit,
    onToggleLike: (Quote) -> Unit,
    onToggleFavorite: (Quote) -> Unit,
    onShareQuote: (Quote) -> Unit,
    onExportImage: (Quote) -> Unit,
    onAddComment: (text: String, onDone: () -> Unit) -> Unit,
    onDeleteComment: (commentId: String) -> Unit,
    onSubmitReport: (targetType: String, commentId: String?, snippet: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var commentText by remember { mutableStateOf("") }
    var reportTarget by remember { mutableStateOf<Triple<String, String?, String>?>(null) }
    var reportReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "صفحة الاقتباس",
                        fontFamily = CairoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (quote == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else {
                val topicEnum = QuoteTopic.fromLabel(quote.topic)
                val accent = if (isDarkTheme) topicEnum.darkAccent else topicEnum.lightAccent
                val container = if (isDarkTheme) topicEnum.containerDark else topicEnum.containerLight
                val shareableUrl = "https://athar.app/quote/${quote.id}"

                LazyColumn(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item(key = "quote_detail_card") {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.5.dp, accent.copy(alpha = 0.45f)),
                            tonalElevation = 3.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Surface(
                                    color = container,
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = quote.topic,
                                        color = accent,
                                        fontFamily = CairoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "«",
                                    fontFamily = ArefRuqaaFontFamily,
                                    fontSize = 40.sp,
                                    color = accent
                                )
                                Text(
                                    text = quote.text,
                                    fontFamily = AmiriFontFamily,
                                    fontSize = 24.sp,
                                    lineHeight = 40.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(18.dp))
                                HorizontalDivider(
                                    modifier = Modifier.width(80.dp),
                                    color = accent.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(16.dp))

                                // Author Wikipedia Profile Card
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        if (quote.authorImageUrl.isNotBlank()) {
                                            AsyncImage(
                                                model = quote.authorImageUrl,
                                                contentDescription = quote.authorName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(52.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(52.dp)
                                                    .clip(CircleShape)
                                                    .background(container),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Person,
                                                    contentDescription = quote.authorName,
                                                    tint = accent
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    text = quote.authorName,
                                                    fontFamily = CairoFontFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp
                                                )
                                                if (quote.isAuthorVerified) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Verified,
                                                        contentDescription = "موثّق",
                                                        tint = accent,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                            if (quote.source.isNotBlank()) {
                                                Text(
                                                    text = quote.source,
                                                    fontFamily = CairoFontFamily,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }

                                    if (quote.wikipediaUrl.isNotBlank()) {
                                        OutlinedButton(
                                            onClick = {
                                                runCatching {
                                                    context.startActivity(
                                                        Intent(Intent.ACTION_VIEW, Uri.parse(quote.wikipediaUrl))
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(Icons.Outlined.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("ويكيبيديا", fontFamily = CairoFontFamily, fontSize = 12.sp)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Shareable Deep Link URL Preview
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Link,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = shareableUrl,
                                            fontFamily = CairoFontFamily,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                // Actions Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    IconButton(onClick = { onToggleLike(quote) }) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                                contentDescription = "إعجاب",
                                                tint = if (isLiked) Color(0xFFD32F2F) else MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(quote.likesCount.toString(), fontFamily = CairoFontFamily, fontSize = 13.sp)
                                        }
                                    }
                                    IconButton(onClick = { onToggleFavorite(quote) }) {
                                        Icon(
                                            imageVector = if (isFavorited) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                            contentDescription = "مفضلة",
                                            tint = if (isFavorited) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    IconButton(onClick = { onExportImage(quote) }) {
                                        Icon(
                                            imageVector = Icons.Outlined.Image,
                                            contentDescription = "حمّل كصورة",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(onClick = { onShareQuote(quote) }) {
                                        Icon(
                                            imageVector = Icons.Outlined.Share,
                                            contentDescription = "مشاركة"
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            reportTarget = Triple("quote", null, quote.text)
                                            reportReason = ""
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Flag,
                                            contentDescription = "إبلاغ"
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item(key = "detail_ad_slot") {
                        AdSlotBanner()
                    }

                    item(key = "comments_header") {
                        Text(
                            text = "التعليقات (${comments.size})",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }

                    item(key = "comment_input") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = commentText,
                                onValueChange = { commentText = it },
                                placeholder = {
                                    Text("أضف تعليقك الجميل…", fontFamily = CairoFontFamily)
                                },
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("comment_input")
                            )
                            Button(
                                onClick = {
                                    val trimmed = commentText.trim()
                                    if (trimmed.isNotEmpty()) {
                                        onAddComment(trimmed) {
                                            commentText = ""
                                        }
                                    }
                                },
                                enabled = commentText.isNotBlank(),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("send_comment_button")
                            ) {
                                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "إرسال التعليق")
                            }
                        }
                    }

                    if (comments.isEmpty()) {
                        item(key = "no_comments") {
                            Text(
                                text = "كن أول من يترك تعليقاً على هذا الاقتباس.",
                                fontFamily = CairoFontFamily,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    } else {
                        items(items = comments, key = { it.id }) { comment ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = comment.userName,
                                            fontFamily = CairoFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = comment.text,
                                            fontFamily = CairoFontFamily,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Row {
                                        if (comment.userId == currentUserId || isOwner) {
                                            IconButton(onClick = { onDeleteComment(comment.id) }) {
                                                Icon(
                                                    imageVector = Icons.Outlined.DeleteOutline,
                                                    contentDescription = "حذف التعليق",
                                                    tint = MaterialTheme.colorScheme.error
                                                )
                                            }
                                        } else {
                                            IconButton(
                                                onClick = {
                                                    reportTarget = Triple("comment", comment.id, comment.text)
                                                    reportReason = ""
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.Flag,
                                                    contentDescription = "الإبلاغ عن التعليق"
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (reportTarget != null) {
        val (targetType, commentId, snippet) = reportTarget!!
        AlertDialog(
            onDismissRequest = { reportTarget = null },
            title = {
                Text(
                    text = if (targetType == "comment") "الإبلاغ عن تعليق" else "الإبلاغ عن اقتباس",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                OutlinedTextField(
                    value = reportReason,
                    onValueChange = { reportReason = it },
                    placeholder = { Text("سبب البلاغ…", fontFamily = CairoFontFamily) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reportReason.trim().length >= 3) {
                            onSubmitReport(targetType, commentId, snippet, reportReason.trim())
                            reportTarget = null
                        }
                    },
                    enabled = reportReason.trim().length >= 3
                ) {
                    Text("إرسال", fontFamily = CairoFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { reportTarget = null }) {
                    Text("إلغاء", fontFamily = CairoFontFamily)
                }
            }
        )
    }
}
