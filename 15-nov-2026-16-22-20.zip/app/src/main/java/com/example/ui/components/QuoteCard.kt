package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Comment
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Quote
import com.example.data.model.QuoteTopic
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.ArefRuqaaFontFamily
import com.example.ui.theme.CairoFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuoteCard(
    quote: Quote,
    isLiked: Boolean,
    isFavorited: Boolean,
    isDarkTheme: Boolean = isSystemInDarkTheme(),
    isHighlighted: Boolean = false,
    onCardClick: () -> Unit,
    onLikeClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onShareClick: () -> Unit,
    onExportImageClick: () -> Unit,
    onReportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val topicEnum = remember(quote.topic) { QuoteTopic.fromLabel(quote.topic) }
    val topicAccent = if (isDarkTheme) topicEnum.darkAccent else topicEnum.lightAccent
    val topicContainer = if (isDarkTheme) topicEnum.containerDark else topicEnum.containerLight

    val interactionSource = remember { MutableInteractionSource() }
    val isHovered by interactionSource.collectIsHoveredAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val activeGlow = isHovered || isPressed || isHighlighted

    val glowElevation by animateDpAsState(
        targetValue = if (activeGlow) 14.dp else 4.dp,
        animationSpec = spring(),
        label = "card_glow_elevation"
    )
    val borderColor by animateColorAsState(
        targetValue = if (activeGlow) topicAccent.copy(alpha = 0.75f)
        else MaterialTheme.colorScheme.outlineVariant,
        label = "card_glow_border"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = glowElevation,
                shape = RoundedCornerShape(24.dp),
                ambientColor = topicAccent.copy(alpha = 0.45f),
                spotColor = topicAccent.copy(alpha = 0.55f)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onCardClick
            )
            .testTag("quote_card_${quote.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(if (activeGlow) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            topicContainer.copy(alpha = 0.22f),
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .padding(18.dp)
        ) {
            // Top Row: Topic chip + Owner badge + Decorative quotation glyph
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = topicContainer,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, topicAccent.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = quote.topic,
                            color = topicAccent,
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    if (quote.isOwnerQuote) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "مختارات أثر",
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontFamily = CairoFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "«",
                    fontFamily = ArefRuqaaFontFamily,
                    fontSize = 30.sp,
                    color = topicAccent.copy(alpha = 0.65f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quote Body
            Text(
                text = quote.text,
                fontFamily = AmiriFontFamily,
                fontSize = 21.sp,
                lineHeight = 35.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Author row with Wikipedia photo, verified badge & external Wikipedia link
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (quote.authorImageUrl.isNotBlank()) {
                        AsyncImage(
                            model = quote.authorImageUrl,
                            contentDescription = "صورة ${quote.authorName}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(topicContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Person,
                                contentDescription = quote.authorName,
                                tint = topicAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = quote.authorName,
                                fontFamily = CairoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (quote.isAuthorVerified) {
                                Icon(
                                    imageVector = Icons.Filled.Verified,
                                    contentDescription = "كاتب موثّق",
                                    tint = topicAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        if (quote.source.isNotBlank()) {
                            Text(
                                text = quote.source,
                                fontFamily = CairoFontFamily,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (quote.wikipediaUrl.isNotBlank()) {
                    Surface(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(quote.wikipediaUrl))
                                )
                            }
                        },
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.OpenInNew,
                                contentDescription = "صفحة ويكيبيديا",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "ويكيبيديا",
                                fontFamily = CairoFontFamily,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))
            Spacer(modifier = Modifier.height(6.dp))

            // Action Bar (all interactive targets >= 48dp)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalArrangement = Arrangement.Center
            ) {
                // Like with live counter
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onLikeClick)
                        .minimumInteractiveComponentSize()
                        .padding(horizontal = 8.dp)
                        .testTag("like_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "إعجاب",
                        tint = if (isLiked) Color(0xFFD32F2F) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = quote.likesCount.toString(),
                        fontFamily = CairoFontFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isLiked) Color(0xFFD32F2F) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Comments button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onCardClick)
                        .minimumInteractiveComponentSize()
                        .padding(horizontal = 8.dp)
                        .testTag("comments_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Comment,
                        contentDescription = "التعليقات",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = quote.commentsCount.toString(),
                        fontFamily = CairoFontFamily,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Favorite button
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.testTag("favorite_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorited) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "حفظ في المفضلة",
                        tint = if (isFavorited) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Export as Image Card button
                IconButton(
                    onClick = onExportImageClick,
                    modifier = Modifier.testTag("export_image_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Image,
                        contentDescription = "حمّل كصورة",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                // Share link & quote
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.testTag("share_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "مشاركة الاقتباس",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Report button
                IconButton(
                    onClick = onReportClick,
                    modifier = Modifier.testTag("report_button_${quote.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Flag,
                        contentDescription = "إبلاغ",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
