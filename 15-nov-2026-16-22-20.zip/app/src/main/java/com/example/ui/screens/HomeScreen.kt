package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Quote
import com.example.data.model.QuoteTopic
import com.example.ui.components.AdSlotBanner
import com.example.ui.components.QuoteCard
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.theme.ArefRuqaaFontFamily
import com.example.ui.theme.CairoFontFamily
import com.example.ui.viewmodel.UiState

@Composable
fun HomeScreen(
    quotesState: UiState<List<Quote>>,
    quoteOfTheDay: Quote?,
    searchQuery: String,
    selectedTopic: QuoteTopic?,
    likedQuoteIds: Set<String>,
    favoriteIds: Set<String>,
    isDarkTheme: Boolean,
    isOwner: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onSelectTopic: (QuoteTopic?) -> Unit,
    onShuffleQuoteOfTheDay: () -> Unit,
    onOpenQuoteDetail: (String) -> Unit,
    onToggleLike: (Quote) -> Unit,
    onToggleFavorite: (Quote) -> Unit,
    onShareQuote: (Quote) -> Unit,
    onExportQuoteImage: (Quote) -> Unit,
    onSubmitReport: (quote: Quote, reason: String) -> Unit,
    onSeedStarterQuotes: () -> Unit,
    modifier: Modifier = Modifier
) {
    var quoteToReport by remember { mutableStateOf<Quote?>(null) }
    var reportReason by remember { mutableStateOf("") }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Quote of the Day Hero Card
            if (quoteOfTheDay != null) {
                item(key = "quote_of_the_day") {
                    QuoteOfTheDayBanner(
                        quote = quoteOfTheDay,
                        isFavorited = favoriteIds.contains(quoteOfTheDay.id),
                        onShuffle = onShuffleQuoteOfTheDay,
                        onToggleFavorite = { onToggleFavorite(quoteOfTheDay) },
                        onOpen = { onOpenQuoteDetail(quoteOfTheDay.id) }
                    )
                }
            }

            // 2. Instant Search Field
            item(key = "search_bar") {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = "ابحث في نص الاقتباس أو اسم الكاتب…",
                            fontFamily = CairoFontFamily,
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "بحث",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Outlined.Close,
                                    contentDescription = "مسح البحث"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_search_input")
                )
            }

            // 3. Topic Filter Chips with dedicated colors
            item(key = "topic_filters") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedTopic == null,
                        onClick = { onSelectTopic(null) },
                        label = {
                            Text(
                                text = "الكل",
                                fontFamily = CairoFontFamily,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.testTag("topic_chip_all")
                    )

                    QuoteTopic.entries.forEach { topic ->
                        val isSelected = selectedTopic == topic
                        val accent = if (isDarkTheme) topic.darkAccent else topic.lightAccent
                        val container = if (isDarkTheme) topic.containerDark else topic.containerLight

                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                onSelectTopic(if (isSelected) null else topic)
                            },
                            label = {
                                Text(
                                    text = topic.labelAr,
                                    fontFamily = CairoFontFamily,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = container,
                                selectedLabelColor = accent
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = accent.copy(alpha = 0.35f),
                                selectedBorderColor = accent
                            ),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.testTag("topic_chip_${topic.name}")
                        )
                    }
                }
            }

            // 4. Quotes Feed State
            when (quotesState) {
                is UiState.Loading -> {
                    item(key = "loading_state") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                is UiState.Error -> {
                    item(key = "error_state") {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = quotesState.message,
                                fontFamily = CairoFontFamily,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(18.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                is UiState.Success -> {
                    val quotes = quotesState.data
                    if (quotes.isEmpty()) {
                        item(key = "empty_state") {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 2.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.AutoAwesome,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (searchQuery.isNotBlank() || selectedTopic != null) {
                                            "لا توجد اقتباسات مطابقة لبحثك حالياً"
                                        } else {
                                            "المكتبة قيد التجهيز بأول الاقتباسات"
                                        },
                                        fontFamily = CairoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    if (isOwner && searchQuery.isBlank() && selectedTopic == null) {
                                        Spacer(modifier = Modifier.height(14.dp))
                                        Button(
                                            onClick = onSeedStarterQuotes,
                                            modifier = Modifier.testTag("seed_starter_quotes_button")
                                        ) {
                                            Text(
                                                text = "نشر المختارات التأسيسية",
                                                fontFamily = CairoFontFamily,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        itemsIndexed(
                            items = quotes,
                            key = { _, item -> item.id }
                        ) { index, quote ->
                            Column(
                                modifier = Modifier.animateItem(),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                QuoteCard(
                                    quote = quote,
                                    isLiked = likedQuoteIds.contains(quote.id),
                                    isFavorited = favoriteIds.contains(quote.id),
                                    isDarkTheme = isDarkTheme,
                                    onCardClick = { onOpenQuoteDetail(quote.id) },
                                    onLikeClick = { onToggleLike(quote) },
                                    onFavoriteClick = { onToggleFavorite(quote) },
                                    onShareClick = { onShareQuote(quote) },
                                    onExportImageClick = { onExportQuoteImage(quote) },
                                    onReportClick = {
                                        quoteToReport = quote
                                        reportReason = ""
                                    }
                                )

                                // Clean ad-ready slot every 4 cards without interrupting reading flow
                                if ((index + 1) % 4 == 0) {
                                    AdSlotBanner()
                                }
                            }
                        }
                    }
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (quoteToReport != null) {
        val target = quoteToReport!!
        AlertDialog(
            onDismissRequest = { quoteToReport = null },
            title = {
                Text(
                    text = "الإبلاغ عن اقتباس",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "اذكر سبب البلاغ ليتم مراجعته من قِبل إدارة أثر:",
                        fontFamily = CairoFontFamily,
                        fontSize = 14.sp
                    )
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        placeholder = {
                            Text("مثال: محتوى مسيء أو نسبة غير صحيحة…", fontFamily = CairoFontFamily)
                        },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_reason_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reportReason.trim().length >= 3) {
                            onSubmitReport(target, reportReason.trim())
                            quoteToReport = null
                        }
                    },
                    enabled = reportReason.trim().length >= 3,
                    modifier = Modifier.testTag("confirm_report_button")
                ) {
                    Text("إرسال البلاغ", fontFamily = CairoFontFamily)
                }
            },
            dismissButton = {
                TextButton(onClick = { quoteToReport = null }) {
                    Text("إلغاء", fontFamily = CairoFontFamily)
                }
            }
        )
    }
}

@Composable
private fun QuoteOfTheDayBanner(
    quote: Quote,
    isFavorited: Boolean,
    onShuffle: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpen: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)),
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onOpen)
            .testTag("quote_of_the_day_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF6B1D2F),
                            Color(0xFF47101E)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = null,
                        tint = Color(0xFFE7C26B),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "اقتباس اليوم",
                        fontFamily = ArefRuqaaFontFamily,
                        fontSize = 22.sp,
                        color = Color(0xFFE7C26B)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onShuffle,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("shuffle_qotd_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Shuffle,
                            contentDescription = "تبديل الاقتباس عشوائياً",
                            tint = Color(0xFFFBF3E4)
                        )
                    }
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("favorite_qotd_button")
                    ) {
                        Icon(
                            imageVector = if (isFavorited) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "حفظ في المفضلة",
                            tint = if (isFavorited) Color(0xFFE7C26B) else Color(0xFFFBF3E4)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            AnimatedContent(
                targetState = quote,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "qotd_transition"
            ) { current ->
                Column {
                    Text(
                        text = "«${current.text}»",
                        fontFamily = AmiriFontFamily,
                        fontSize = 21.sp,
                        lineHeight = 34.sp,
                        color = Color(0xFFFDF8EE)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "— ${current.authorName}  •  ${current.topic}",
                        fontFamily = CairoFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = Color(0xFFE7C26B)
                    )
                }
            }
        }
    }
}
