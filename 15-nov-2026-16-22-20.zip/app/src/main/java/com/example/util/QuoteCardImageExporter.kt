package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.CardExportTemplate
import com.example.data.model.Quote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object QuoteCardImageExporter {

    private const val CARD_WIDTH = 1080
    private const val CARD_HEIGHT = 1350

    suspend fun renderQuoteBitmap(
        context: Context,
        quote: Quote,
        template: CardExportTemplate
    ): Bitmap = withContext(Dispatchers.Default) {
        val bitmap = Bitmap.createBitmap(CARD_WIDTH, CARD_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, CARD_WIDTH.toFloat(), CARD_HEIGHT.toFloat(),
                template.bgTopHex.toInt(),
                template.bgBottomHex.toInt(),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, CARD_WIDTH.toFloat(), CARD_HEIGHT.toFloat(), bgPaint)

        // Subtle ornamental double border
        val accentColor = template.accentHex.toInt()
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = accentColor
            alpha = 110
            strokeWidth = 3f
        }
        canvas.drawRoundRect(
            RectF(48f, 48f, CARD_WIDTH - 48f, CARD_HEIGHT - 48f),
            44f, 44f, borderPaint
        )
        borderPaint.alpha = 55
        borderPaint.strokeWidth = 1.5f
        canvas.drawRoundRect(
            RectF(66f, 66f, CARD_WIDTH - 66f, CARD_HEIGHT - 66f),
            36f, 36f, borderPaint
        )

        val arefTypeface = ResourcesCompat.getFont(context, R.font.aref_ruqaa) ?: Typeface.SERIF
        val amiriTypeface = ResourcesCompat.getFont(context, R.font.amiri) ?: Typeface.SERIF
        val cairoTypeface = ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.SANS_SERIF

        // Topic pill at top center
        val topicPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 40
        }
        val topicTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            typeface = cairoTypeface
            textSize = 30f
            textAlign = Paint.Align.CENTER
        }
        val topicLabel = "✦  ${quote.topic}  ✦"
        val pillWidth = topicTextPaint.measureText(topicLabel) + 72f
        val pillRect = RectF(
            (CARD_WIDTH - pillWidth) / 2f,
            120f,
            (CARD_WIDTH + pillWidth) / 2f,
            184f
        )
        canvas.drawRoundRect(pillRect, 32f, 32f, topicPaint)
        canvas.drawText(topicLabel, CARD_WIDTH / 2f, 163f, topicTextPaint)

        // Decorative opening quotation mark
        val quoteMarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 150
            typeface = arefTypeface
            textSize = 110f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("«", CARD_WIDTH / 2f, 320f, quoteMarkPaint)

        // Quote text centered with StaticLayout
        val quoteTextSize = when {
            quote.text.length > 260 -> 40f
            quote.text.length > 150 -> 48f
            else -> 58f
        }
        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = template.textHex.toInt()
            typeface = amiriTypeface
            textSize = quoteTextSize
        }
        val contentWidth = CARD_WIDTH - 220
        val staticLayout = StaticLayout.Builder
            .obtain(quote.text, 0, quote.text.length, textPaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(18f, 1.15f)
            .build()

        val textStartY = (CARD_HEIGHT * 0.47f) - (staticLayout.height / 2f)
        canvas.save()
        canvas.translate(110f, textStartY.coerceAtLeast(350f))
        staticLayout.draw(canvas)
        canvas.restore()

        // Divider + Author
        val authorY = (textStartY + staticLayout.height + 90f).coerceAtMost(CARD_HEIGHT - 280f)
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 160
            strokeWidth = 3f
        }
        canvas.drawLine(CARD_WIDTH / 2f - 70f, authorY - 38f, CARD_WIDTH / 2f + 70f, authorY - 38f, dividerPaint)

        val authorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = template.subTextHex.toInt()
            typeface = cairoTypeface
            textSize = 36f
            textAlign = Paint.Align.CENTER
        }
        val verifiedMark = if (quote.isAuthorVerified) " ✓" else ""
        canvas.drawText("— ${quote.authorName}$verifiedMark", CARD_WIDTH / 2f, authorY + 10f, authorPaint)

        if (quote.source.isNotBlank()) {
            val sourcePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = template.subTextHex.toInt()
                alpha = 190
                typeface = cairoTypeface
                textSize = 26f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(quote.source, CARD_WIDTH / 2f, authorY + 56f, sourcePaint)
        }

        // Bottom signature: Custom Alif-Pen + Butterfly Logo + «ثر»
        drawAtharWatermark(canvas, accentColor, template.textHex.toInt(), arefTypeface, cairoTypeface)

        bitmap
    }

    private fun drawAtharWatermark(
        canvas: Canvas,
        accentColor: Int,
        textColor: Int,
        arefTypeface: Typeface,
        cairoTypeface: Typeface
    ) {
        val centerX = CARD_WIDTH / 2f
        val baseY = CARD_HEIGHT - 125f

        // Draw Alif Calligraphy Pen + Butterfly on the right side of «ثر» (RTL)
        val penX = centerX + 54f
        val penTop = baseY - 58f
        val penBottom = baseY + 14f

        val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            style = Paint.Style.FILL
        }

        // Butterfly wings perched above Alif
        val bfY = penTop - 18f
        val leftWing = Path().apply {
            moveTo(penX, bfY)
            cubicTo(penX - 28f, bfY - 24f, penX - 30f, bfY + 4f, penX - 8f, bfY + 10f)
            close()
        }
        val rightWing = Path().apply {
            moveTo(penX, bfY)
            cubicTo(penX + 28f, bfY - 24f, penX + 30f, bfY + 4f, penX + 8f, bfY + 10f)
            close()
        }
        canvas.drawPath(leftWing, goldPaint)
        canvas.drawPath(rightWing, goldPaint)

        // Pen nib + Alif shaft
        val nib = Path().apply {
            moveTo(penX, penTop)
            lineTo(penX + 8f, penTop + 18f)
            lineTo(penX - 8f, penTop + 18f)
            close()
        }
        canvas.drawPath(nib, goldPaint)

        val shaft = Path().apply {
            moveTo(penX - 5f, penTop + 22f)
            lineTo(penX + 5f, penTop + 22f)
            lineTo(penX - 1f, penBottom)
            lineTo(penX - 6f, penBottom - 8f)
            close()
        }
        canvas.drawPath(shaft, goldPaint)

        // «ثر» in Aref Ruqaa
        val wordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            typeface = arefTypeface
            textSize = 54f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("ثر", penX - 14f, baseY + 6f, wordPaint)

        val urlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            alpha = 180
            typeface = cairoTypeface
            textSize = 22f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("athar.app  •  مشاركة الأثر الطيب", centerX, CARD_HEIGHT - 74f, urlPaint)
    }

    suspend fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        fileNamePrefix: String = "athar_quote"
    ): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val fileName = "${fileNamePrefix}_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Athar")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("تعذر إنشاء ملف الصورة في المعرض")
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                } ?: error("تعذر فتح مجرى الحفظ")
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.cacheDir
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }
        }
    }

    suspend fun shareBitmap(
        context: Context,
        bitmap: Bitmap,
        quote: Quote
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val cardsDir = File(context.cacheDir, "cards").apply { if (!exists()) mkdirs() }
            val file = File(cardsDir, "athar_card_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(
                    Intent.EXTRA_TEXT,
                    "«${quote.text}»\n— ${quote.authorName}\nhttps://athar.app/quote/${quote.id}"
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            withContext(Dispatchers.Main) {
                context.startActivity(Intent.createChooser(shareIntent, "مشاركة بطاقة أثر"))
            }
        }
    }
}
