package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.model.Quote
import com.example.data.remote.WikipediaRepository
import com.example.data.repository.AtharRepository
import com.example.data.repository.FirestoreClientFactory
import com.example.data.repository.ThemePreferencesRepository
import com.example.ui.components.AtharBrandLogo
import com.example.ui.components.CardExportSheet
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ContributeScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.QuoteDetailScreen
import com.example.ui.screens.attemptAutoSignIn
import com.example.ui.screens.signOutUser
import com.example.ui.theme.AtharTheme
import com.example.ui.theme.CairoFontFamily
import com.example.ui.viewmodel.AtharViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

private const val ROUTE_HOME = "home"
private const val ROUTE_FAVORITES = "favorites"
private const val ROUTE_CONTRIBUTE = "contribute"
private const val ROUTE_ADMIN = "admin"
private const val ROUTE_DETAIL = "quote/{quoteId}"

private data class AtharNavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int = 0
)

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDeepLinkQuoteId = extractDeepLinkQuoteId(intent)

        setContent {
            val context = LocalContext.current
            val themePrefs = remember { ThemePreferencesRepository(context.applicationContext) }
            val systemDark = isSystemInDarkTheme()
            val storedDarkPref by themePrefs.isDarkModeFlow.collectAsState(initial = null)
            val isDarkTheme = storedDarkPref ?: systemDark
            val coroutineScope = rememberCoroutineScope()

            AtharTheme(darkTheme = isDarkTheme) {
                AtharRootApp(
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = {
                        coroutineScope.launch {
                            themePrefs.setDarkMode(!isDarkTheme)
                        }
                    },
                    initialDeepLinkQuoteId = initialDeepLinkQuoteId
                )
            }
        }
    }

    private fun extractDeepLinkQuoteId(intent: Intent?): String? {
        val data = intent?.data ?: return null
        if (data.scheme == "https" && data.host == "athar.app") {
            return data.pathSegments.getOrNull(1)?.takeIf { it.isNotBlank() }
        }
        if (data.scheme == "athar" && data.host == "quote") {
            return data.lastPathSegment?.takeIf { it.isNotBlank() }
        }
        return null
    }
}

@Composable
fun AtharRootApp(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    initialDeepLinkQuoteId: String?,
    auth: FirebaseAuth = Firebase.auth
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            isDarkTheme = isDarkTheme,
            onToggleTheme = onToggleTheme,
            onAuthSuccess = {}
        )
    } else {
        key(user.uid) {
            val viewModel: AtharViewModel = viewModel(
                key = user.uid,
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val db = FirestoreClientFactory.getInstance(app)
                        AtharViewModel(
                            repository = AtharRepository(db, Firebase.auth),
                            wikipediaRepository = WikipediaRepository(),
                            themePreferences = ThemePreferencesRepository(app),
                            currentUserId = user.uid,
                            currentUserEmail = user.email,
                            currentUserName = user.displayName ?: user.email?.substringBefore('@') ?: "قارئ أثر"
                        )
                    }
                }
            )
            AtharMainShell(
                viewModel = viewModel,
                isDarkTheme = isDarkTheme,
                onToggleTheme = { viewModel.setDarkMode(!isDarkTheme) },
                onSignOut = {
                    signOutUser(credentialManager, scope)
                },
                initialDeepLinkQuoteId = initialDeepLinkQuoteId
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AtharMainShell(
    viewModel: AtharViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onSignOut: () -> Unit,
    initialDeepLinkQuoteId: String?
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val quotesState by viewModel.filteredQuotesState.collectAsStateWithLifecycle()
    val quoteOfTheDay by viewModel.quoteOfTheDay.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedTopic by viewModel.selectedTopic.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val likedQuoteIds by viewModel.likedQuoteIds.collectAsStateWithLifecycle()
    val mySubmissions by viewModel.mySubmissions.collectAsStateWithLifecycle()
    val pendingQuotes by viewModel.pendingQuotes.collectAsStateWithLifecycle()
    val openReports by viewModel.openReports.collectAsStateWithLifecycle()
    val authorPreview by viewModel.authorPreview.collectAsStateWithLifecycle()
    val isLookingUpAuthor by viewModel.isLookingUpAuthor.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()

    var quoteForImageExport by remember { mutableStateOf<Quote?>(null) }

    LaunchedEffect(actionMessage) {
        val msg = actionMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    LaunchedEffect(initialDeepLinkQuoteId) {
        if (!initialDeepLinkQuoteId.isNullOrBlank()) {
            navController.navigate("quote/$initialDeepLinkQuoteId")
        }
    }

    val navItems = buildList {
        add(
            AtharNavItem(
                route = ROUTE_HOME,
                label = "الرئيسية",
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home
            )
        )
        add(
            AtharNavItem(
                route = ROUTE_FAVORITES,
                label = "المفضلة",
                selectedIcon = Icons.Filled.Bookmark,
                unselectedIcon = Icons.Outlined.BookmarkBorder
            )
        )
        add(
            AtharNavItem(
                route = ROUTE_CONTRIBUTE,
                label = "اترك أثرك",
                selectedIcon = Icons.Filled.Create,
                unselectedIcon = Icons.Outlined.Create
            )
        )
        if (viewModel.isOwner) {
            add(
                AtharNavItem(
                    route = ROUTE_ADMIN,
                    label = "المالك",
                    selectedIcon = Icons.Filled.AdminPanelSettings,
                    unselectedIcon = Icons.Outlined.AdminPanelSettings,
                    badgeCount = pendingQuotes.size + openReports.size
                )
            )
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val isDetailRoute = currentDestination?.route == ROUTE_DETAIL

    val shareQuoteAction: (Quote) -> Unit = { quote ->
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_TEXT,
                "«${quote.text}»\n— ${quote.authorName}\n\nاقرأ المزيد على منصة أثر:\nhttps://athar.app/quote/${quote.id}"
            )
        }
        context.startActivity(Intent.createChooser(shareIntent, "مشاركة الاقتباس"))
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (!isDetailRoute) {
                    TopAppBar(
                        title = {
                            AtharBrandLogo(
                                penHeight = 36.dp,
                                wordSize = 26.sp
                            )
                        },
                        actions = {
                            IconButton(
                                onClick = onToggleTheme,
                                modifier = Modifier.testTag("theme_toggle_button")
                            ) {
                                Icon(
                                    imageVector = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                    contentDescription = "تبديل الوضع الليلي والنهاري"
                                )
                            }
                            IconButton(
                                onClick = onSignOut,
                                modifier = Modifier.testTag("sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Logout,
                                    contentDescription = "تسجيل الخروج"
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }
            },
            bottomBar = {
                if (!useNavigationRail && !isDetailRoute) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hierarchy?.any { it.route == item.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (item.badgeCount > 0) {
                                                Badge { Text(item.badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = item.label,
                                        fontFamily = CairoFontFamily,
                                        fontSize = 12.sp
                                    )
                                },
                                modifier = Modifier.testTag("nav_${item.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail && !isDetailRoute) {
                    NavigationRail(containerColor = MaterialTheme.colorScheme.surface) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hierarchy?.any { it.route == item.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (item.badgeCount > 0) {
                                                Badge { Text(item.badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = item.label,
                                        fontFamily = CairoFontFamily,
                                        fontSize = 12.sp
                                    )
                                }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                quotesState = quotesState,
                                quoteOfTheDay = quoteOfTheDay,
                                searchQuery = searchQuery,
                                selectedTopic = selectedTopic,
                                likedQuoteIds = likedQuoteIds,
                                favoriteIds = favoriteIds,
                                isDarkTheme = isDarkTheme,
                                isOwner = viewModel.isOwner,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onSelectTopic = viewModel::selectTopic,
                                onShuffleQuoteOfTheDay = viewModel::shuffleQuoteOfTheDay,
                                onOpenQuoteDetail = { quoteId ->
                                    navController.navigate("quote/$quoteId")
                                },
                                onToggleLike = viewModel::toggleLike,
                                onToggleFavorite = viewModel::toggleFavorite,
                                onShareQuote = shareQuoteAction,
                                onExportQuoteImage = { quote -> quoteForImageExport = quote },
                                onSubmitReport = { quote, reason ->
                                    viewModel.submitReport(
                                        targetType = "quote",
                                        quoteId = quote.id,
                                        targetSnippet = quote.text,
                                        reason = reason
                                    )
                                },
                                onSeedStarterQuotes = viewModel::seedStarterQuotes
                            )
                        }

                        composable(ROUTE_FAVORITES) {
                            FavoritesScreen(
                                favorites = favorites,
                                isDarkTheme = isDarkTheme,
                                onOpenQuoteDetail = { quoteId ->
                                    navController.navigate("quote/$quoteId")
                                },
                                onRemoveFavorite = { quote ->
                                    viewModel.toggleFavorite(quote)
                                }
                            )
                        }

                        composable(ROUTE_CONTRIBUTE) {
                            ContributeScreen(
                                authorPreview = authorPreview,
                                isLookingUpAuthor = isLookingUpAuthor,
                                mySubmissions = mySubmissions,
                                onAuthorNameChanged = viewModel::lookupAuthorPreview,
                                onSubmitQuote = { text, author, topic, source, onDone ->
                                    viewModel.submitQuote(
                                        text = text,
                                        authorName = author,
                                        topic = topic,
                                        source = source,
                                        publishImmediatelyAsOwner = false,
                                        onSuccess = { onDone() }
                                    )
                                }
                            )
                        }

                        if (viewModel.isOwner) {
                            composable(ROUTE_ADMIN) {
                                AdminDashboardScreen(
                                    pendingQuotes = pendingQuotes,
                                    openReports = openReports,
                                    authorPreview = authorPreview,
                                    isLookingUpAuthor = isLookingUpAuthor,
                                    onAuthorNameChanged = viewModel::lookupAuthorPreview,
                                    onPublishOwnerQuote = { text, author, topic, source, onDone ->
                                        viewModel.submitQuote(
                                            text = text,
                                            authorName = author,
                                            topic = topic,
                                            source = source,
                                            publishImmediatelyAsOwner = true,
                                            onSuccess = { onDone() }
                                        )
                                    },
                                    onApproveQuote = viewModel::approvePendingQuote,
                                    onRejectQuote = viewModel::rejectPendingQuote,
                                    onResolveReport = viewModel::resolveReport,
                                    onSeedStarterQuotes = viewModel::seedStarterQuotes
                                )
                            }
                        }

                        composable(
                            route = ROUTE_DETAIL,
                            arguments = listOf(navArgument("quoteId") { type = NavType.StringType })
                        ) { entry ->
                            val quoteId = entry.arguments?.getString("quoteId").orEmpty()
                            val detailQuote by remember(quoteId) {
                                viewModel.observeQuoteDetail(quoteId)
                            }.collectAsStateWithLifecycle(initialValue = null)
                            val comments by remember(quoteId) {
                                viewModel.observeComments(quoteId)
                            }.collectAsStateWithLifecycle(initialValue = emptyList())

                            QuoteDetailScreen(
                                quote = detailQuote,
                                comments = comments,
                                isLiked = likedQuoteIds.contains(quoteId),
                                isFavorited = favoriteIds.contains(quoteId),
                                currentUserId = viewModel.currentUserId,
                                isOwner = viewModel.isOwner,
                                isDarkTheme = isDarkTheme,
                                onBack = { navController.popBackStack() },
                                onToggleLike = viewModel::toggleLike,
                                onToggleFavorite = viewModel::toggleFavorite,
                                onShareQuote = shareQuoteAction,
                                onExportImage = { q -> quoteForImageExport = q },
                                onAddComment = { text, onDone ->
                                    viewModel.addComment(quoteId, text, onDone)
                                },
                                onDeleteComment = { commentId ->
                                    viewModel.deleteComment(
                                        quoteId = quoteId,
                                        commentId = commentId,
                                        currentCount = detailQuote?.commentsCount ?: 1L
                                    )
                                },
                                onSubmitReport = { type, commentId, snippet, reason ->
                                    viewModel.submitReport(
                                        targetType = type,
                                        quoteId = quoteId,
                                        commentId = commentId,
                                        targetSnippet = snippet,
                                        reason = reason
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (quoteForImageExport != null) {
        CardExportSheet(
            quote = quoteForImageExport!!,
            onDismiss = { quoteForImageExport = null }
        )
    }
}
