package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AdminConfig
import com.example.data.model.FavoriteQuote
import com.example.data.model.Quote
import com.example.data.model.QuoteComment
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteTopic
import com.example.data.model.Report
import com.example.data.model.ReportStatus
import com.example.data.remote.WikipediaRepository
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

object FirestoreClientFactory {
    private val lock = Any()
    @Volatile
    private var configuredDbId: String? = null

    fun getInstance(context: Context): FirebaseFirestore {
        val dbId = context.applicationContext.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        if (configuredDbId != dbId) {
            synchronized(lock) {
                if (configuredDbId != dbId) {
                    runCatching {
                        val settings = FirebaseFirestoreSettings.Builder()
                            .setLocalCacheSettings(
                                PersistentCacheSettings.newBuilder()
                                    .setSizeBytes(100L * 1024L * 1024L)
                                    .build()
                            )
                            .build()
                        db.firestoreSettings = settings
                    }
                    configuredDbId = dbId
                }
            }
        }
        return db
    }
}

class AtharRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val wikipediaRepository: WikipediaRepository = WikipediaRepository()
) {
    constructor(context: Context) : this(
        FirestoreClientFactory.getInstance(context),
        Firebase.auth,
        WikipediaRepository()
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول بحساب Google أولاً.")
    }

    private fun currentUserName(): String {
        val user = auth.currentUser
        return user?.displayName?.takeIf { it.isNotBlank() }
            ?: user?.email?.substringBefore('@')?.takeIf { it.isNotBlank() }
            ?: "قارئ أثر"
    }

    fun isCurrentUserAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.email.equals(AdminConfig.OWNER_EMAIL, ignoreCase = true)
    }

    fun observeApprovedQuotes(): Flow<List<Quote>> = flow {
        requireUserId()
        val path = QUOTES_COLLECTION
        emitAll(
            db.collection(path)
                .whereEqualTo("status", QuoteStatus.APPROVED)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Quote::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeMySubmissions(uid: String): Flow<List<Quote>> = flow {
        val path = QUOTES_COLLECTION
        emitAll(
            db.collection(path)
                .whereEqualTo("submittedByUid", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Quote::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observePendingQuotes(): Flow<List<Quote>> = flow {
        requireUserId()
        val path = QUOTES_COLLECTION
        emitAll(
            db.collection(path)
                .whereEqualTo("status", QuoteStatus.PENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Quote::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeQuoteById(quoteId: String): Flow<Quote?> = flow {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (!snapshot.exists()) null
                    else snapshot.toObject(
                        Quote::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    handleFlowError(error, OperationType.GET, docRef.path)
                    throw error
                }
        )
    }

    fun observeComments(quoteId: String): Flow<List<QuoteComment>> = flow {
        requireUserId()
        val path = "$QUOTES_COLLECTION/$quoteId/$COMMENTS_COLLECTION"
        emitAll(
            db.collection(QUOTES_COLLECTION)
                .document(quoteId)
                .collection(COMMENTS_COLLECTION)
                .whereEqualTo("isPublic", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        QuoteComment::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeFavorites(uid: String): Flow<List<FavoriteQuote>> = flow {
        val path = "$USERS_COLLECTION/$uid/$FAVORITES_COLLECTION"
        emitAll(
            db.collection(USERS_COLLECTION)
                .document(uid)
                .collection(FAVORITES_COLLECTION)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FavoriteQuote::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeLikedQuoteIds(uid: String): Flow<Set<String>> = flow {
        val path = "$USERS_COLLECTION/$uid/$LIKED_QUOTES_COLLECTION"
        emitAll(
            db.collection(USERS_COLLECTION)
                .document(uid)
                .collection(LIKED_QUOTES_COLLECTION)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.map { it.id }.toSet()
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeOpenReports(): Flow<List<Report>> = flow {
        requireUserId()
        val path = REPORTS_COLLECTION
        emitAll(
            db.collection(path)
                .whereEqualTo("status", ReportStatus.OPEN)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Report::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun getQuoteById(quoteId: String): Result<Quote?> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        try {
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) null
            else snapshot.toObject(
                Quote::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    /**
     * Creates a new Quote in Firestore and automatically enriches known authors
     * with their photo and Wikipedia verification link if not explicitly provided.
     */
    suspend fun createQuote(
        text: String,
        authorName: String,
        topic: QuoteTopic = QuoteTopic.WISDOM,
        source: String? = null,
        publishImmediatelyAsOwner: Boolean = false
    ): Result<String> = submitQuote(
        text = text,
        authorName = authorName,
        topic = topic,
        source = source,
        authorImageUrl = null,
        wikipediaUrl = null,
        isAuthorVerified = false,
        publishImmediatelyAsOwner = publishImmediatelyAsOwner
    )

    suspend fun submitQuote(
        text: String,
        authorName: String,
        topic: QuoteTopic,
        source: String?,
        authorImageUrl: String?,
        wikipediaUrl: String?,
        isAuthorVerified: Boolean,
        publishImmediatelyAsOwner: Boolean
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document()
        val isOwnerPublish = publishImmediatelyAsOwner && isCurrentUserAdmin()

        // Automatic known-author resolution when photo/wiki info is missing
        val autoWiki = if (authorImageUrl.isNullOrBlank() || wikipediaUrl.isNullOrBlank()) {
            withTimeoutOrNull(WIKI_ENRICH_TIMEOUT_MS) {
                runCatching { wikipediaRepository.fetchAuthorInfo(authorName) }.getOrNull()
            }
        } else {
            null
        }
        val resolvedImageUrl = authorImageUrl?.takeIf { it.isNotBlank() } ?: autoWiki?.imageUrl
        val resolvedWikiUrl = wikipediaUrl?.takeIf { it.isNotBlank() } ?: autoWiki?.wikipediaUrl
        val resolvedVerified = isAuthorVerified || (autoWiki?.isVerified == true)

        val payload = buildMap<String, Any> {
            put("text", text.trim())
            put("authorName", authorName.trim())
            put("topic", topic.labelAr)
            source?.trim()?.takeIf { it.isNotEmpty() }?.let { put("source", it.take(200)) }
            resolvedImageUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { put("authorImageUrl", it.take(500)) }
            resolvedWikiUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { put("wikipediaUrl", it.take(500)) }
            put("isAuthorVerified", resolvedVerified)
            put("isOwnerQuote", isOwnerPublish)
            put("status", if (isOwnerPublish) QuoteStatus.APPROVED else QuoteStatus.PENDING)
            put("submittedByUid", uid)
            put("submittedByName", currentUserName().take(100))
            put("likesCount", 0L)
            put("commentsCount", 0L)
            put("createdAt", FieldValue.serverTimestamp())
            put("updatedAt", FieldValue.serverTimestamp())
        }
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateQuote(
        quoteId: String,
        text: String,
        authorName: String,
        topic: QuoteTopic,
        source: String? = null
    ): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        val autoWiki = withTimeoutOrNull(WIKI_ENRICH_TIMEOUT_MS) {
            runCatching { wikipediaRepository.fetchAuthorInfo(authorName) }.getOrNull()
        }
        val updates = buildMap<String, Any> {
            put("text", text.trim())
            put("authorName", authorName.trim())
            put("topic", topic.labelAr)
            source?.trim()?.takeIf { it.isNotEmpty() }?.let { put("source", it.take(200)) }
            autoWiki?.imageUrl?.takeIf { it.isNotBlank() }?.let { put("authorImageUrl", it.take(500)) }
            autoWiki?.wikipediaUrl?.takeIf { it.isNotBlank() }?.let { put("wikipediaUrl", it.take(500)) }
            put("isAuthorVerified", autoWiki?.isVerified == true)
            put("updatedAt", FieldValue.serverTimestamp())
        }
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updateAuthorEnrichment(
        quoteId: String,
        authorImageUrl: String?,
        wikipediaUrl: String?,
        isAuthorVerified: Boolean
    ): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        val updates = buildMap<String, Any> {
            authorImageUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { put("authorImageUrl", it.take(500)) }
            wikipediaUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { put("wikipediaUrl", it.take(500)) }
            put("isAuthorVerified", isAuthorVerified)
            put("updatedAt", FieldValue.serverTimestamp())
        }
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun toggleLike(quote: Quote, currentlyLiked: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val quoteRef = db.collection(QUOTES_COLLECTION).document(quote.id)
        val likedRef = db.collection(USERS_COLLECTION)
            .document(uid)
            .collection(LIKED_QUOTES_COLLECTION)
            .document(quote.id)

        try {
            val batch = db.batch()
            if (currentlyLiked) {
                batch.delete(likedRef)
                batch.update(
                    quoteRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    likedRef,
                    mapOf(
                        "quoteId" to quote.id,
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    quoteRef,
                    mapOf(
                        "likesCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, quoteRef.path)
            throw e
        }
    }

    suspend fun toggleFavorite(quote: Quote, currentlyFavorited: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val favRef = db.collection(USERS_COLLECTION)
            .document(uid)
            .collection(FAVORITES_COLLECTION)
            .document(quote.id)
        try {
            if (currentlyFavorited) {
                favRef.delete().await()
            } else {
                val payload = buildMap<String, Any> {
                    put("quoteId", quote.id)
                    put("userId", uid)
                    put("text", quote.text.take(1500))
                    put("authorName", quote.authorName.take(120))
                    put("topic", quote.topic)
                    quote.authorImageUrl.takeIf { it.isNotBlank() }?.let { put("authorImageUrl", it.take(500)) }
                    put("createdAt", FieldValue.serverTimestamp())
                }
                favRef.set(payload).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, favRef.path)
            throw e
        }
    }

    suspend fun addComment(quoteId: String, text: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val quoteRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        val commentRef = quoteRef.collection(COMMENTS_COLLECTION).document()
        val photoUrl = auth.currentUser?.photoUrl?.toString()
        val payload = buildMap<String, Any> {
            put("quoteId", quoteId)
            put("userId", uid)
            put("userName", currentUserName().take(100))
            photoUrl?.takeIf { it.isNotBlank() }?.let { put("userPhotoUrl", it.take(500)) }
            put("text", text.trim().take(600))
            put("isPublic", true)
            put("createdAt", FieldValue.serverTimestamp())
        }
        try {
            val batch = db.batch()
            batch.set(commentRef, payload)
            batch.update(
                quoteRef,
                mapOf(
                    "commentsCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            throw e
        }
    }

    suspend fun deleteComment(quoteId: String, commentId: String, currentCount: Long): Result<Unit> = runCatching {
        requireUserId()
        val quoteRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        val commentRef = quoteRef.collection(COMMENTS_COLLECTION).document(commentId)
        try {
            val batch = db.batch()
            batch.delete(commentRef)
            if (currentCount > 0L) {
                batch.update(
                    quoteRef,
                    mapOf(
                        "commentsCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, commentRef.path)
            throw e
        }
    }

    suspend fun approveQuote(quoteId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        try {
            docRef.update(
                mapOf(
                    "status" to QuoteStatus.APPROVED,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun rejectQuote(quoteId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        try {
            docRef.update(
                mapOf(
                    "status" to QuoteStatus.REJECTED,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteQuote(quoteId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(QUOTES_COLLECTION).document(quoteId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun submitReport(
        targetType: String,
        quoteId: String,
        commentId: String? = null,
        targetSnippet: String,
        reason: String
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val reportRef = db.collection(REPORTS_COLLECTION).document()
        val payload = buildMap<String, Any> {
            put("targetType", targetType)
            put("quoteId", quoteId)
            commentId?.takeIf { it.isNotBlank() }?.let { put("commentId", it) }
            put("targetSnippet", targetSnippet.trim().take(300))
            put("reason", reason.trim().take(300))
            put("reporterUid", uid)
            put("reporterName", currentUserName().take(100))
            put("status", ReportStatus.OPEN)
            put("createdAt", FieldValue.serverTimestamp())
            put("updatedAt", FieldValue.serverTimestamp())
        }
        try {
            reportRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, reportRef.path)
            throw e
        }
    }

    suspend fun updateReportStatus(reportId: String, newStatus: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection(REPORTS_COLLECTION).document(reportId)
        try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun seedStarterOwnerQuotes(starterQuotes: List<Quote>): Result<Int> = runCatching {
        val uid = requireUserId()
        if (!isCurrentUserAdmin()) error("صلاحية النشر التأسيسي مخصصة لمالك المنصة فقط.")
        val existing = db.collection(QUOTES_COLLECTION)
            .whereEqualTo("status", QuoteStatus.APPROVED)
            .limit(1)
            .get()
            .await()
        if (!existing.isEmpty) return@runCatching 0

        val batch = db.batch()
        starterQuotes.forEach { q ->
            val ref = db.collection(QUOTES_COLLECTION).document()
            val autoWiki = if (q.authorImageUrl.isBlank()) {
                runCatching { wikipediaRepository.fetchAuthorInfo(q.authorName) }.getOrNull()
            } else {
                null
            }
            val resolvedImageUrl = q.authorImageUrl.ifBlank { autoWiki?.imageUrl.orEmpty() }
            val resolvedWikiUrl = q.wikipediaUrl.ifBlank { autoWiki?.wikipediaUrl.orEmpty() }
            val payload = buildMap<String, Any> {
                put("text", q.text)
                put("authorName", q.authorName)
                put("topic", q.topic)
                q.source.takeIf { it.isNotBlank() }?.let { put("source", it) }
                resolvedImageUrl.takeIf { it.isNotBlank() }?.let { put("authorImageUrl", it.take(500)) }
                resolvedWikiUrl.takeIf { it.isNotBlank() }?.let { put("wikipediaUrl", it.take(500)) }
                put("isAuthorVerified", q.isAuthorVerified || (autoWiki?.isVerified == true))
                put("isOwnerQuote", true)
                put("status", QuoteStatus.APPROVED)
                put("submittedByUid", uid)
                put("submittedByName", currentUserName().take(100))
                put("likesCount", 0L)
                put("commentsCount", 0L)
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            batch.set(ref, payload)
        }
        batch.commit().await()
        starterQuotes.size
    }

    private fun handleFlowError(error: Throwable, operationType: OperationType, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception) ?: return
        if (auth.currentUser != null) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }

    companion object {
        const val QUOTES_COLLECTION = "quotes"
        const val COMMENTS_COLLECTION = "comments"
        const val USERS_COLLECTION = "users"
        const val FAVORITES_COLLECTION = "favorites"
        const val LIKED_QUOTES_COLLECTION = "likedQuotes"
        const val REPORTS_COLLECTION = "reports"
        private const val WIKI_ENRICH_TIMEOUT_MS = 2500L
    }
}
