package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.atharSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "athar_settings"
)

class ThemePreferencesRepository(private val context: Context) {
    private val darkModeKey = booleanPreferencesKey("is_dark_mode")

    val isDarkModeFlow: Flow<Boolean?> = context.atharSettingsDataStore.data.map { prefs ->
        prefs[darkModeKey]
    }

    suspend fun setDarkMode(isDark: Boolean) {
        context.atharSettingsDataStore.edit { prefs ->
            prefs[darkModeKey] = isDark
        }
    }
}
