package com.example.data.remote

import com.example.data.model.AuthorWikiInfo
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class WikiSummaryResponse(
    val type: String? = null,
    val title: String? = null,
    val description: String? = null,
    val extract: String? = null,
    val thumbnail: WikiImage? = null,
    val originalimage: WikiImage? = null,
    @param:Json(name = "content_urls") val contentUrls: WikiContentUrls? = null
)

@JsonClass(generateAdapter = true)
data class WikiImage(
    val source: String? = null
)

@JsonClass(generateAdapter = true)
data class WikiContentUrls(
    val desktop: WikiDesktopUrl? = null
)

@JsonClass(generateAdapter = true)
data class WikiDesktopUrl(
    val page: String? = null
)

@JsonClass(generateAdapter = true)
data class WikiSearchResponse(
    val query: WikiSearchQuery? = null
)

@JsonClass(generateAdapter = true)
data class WikiSearchQuery(
    val search: List<WikiSearchHit>? = null
)

@JsonClass(generateAdapter = true)
data class WikiSearchHit(
    val title: String? = null
)

interface WikipediaRestApi {
    @GET("api/rest_v1/page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiSummaryResponse

    @GET("w/api.php?action=query&list=search&format=json&utf8=1&srlimit=3")
    suspend fun searchTitle(@Query("srsearch") query: String): WikiSearchResponse
}

class WikipediaRepository {
    private val cache = ConcurrentHashMap<String, AuthorWikiInfo>()

    private val okHttp = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "AtharQuotesAndroid/1.0 (https://athar.app)")
                .build()
            chain.proceed(req)
        }
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val arApi: WikipediaRestApi = Retrofit.Builder()
        .baseUrl("https://ar.wikipedia.org/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(WikipediaRestApi::class.java)

    private val enApi: WikipediaRestApi = Retrofit.Builder()
        .baseUrl("https://en.wikipedia.org/")
        .client(okHttp)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(WikipediaRestApi::class.java)

    suspend fun fetchAuthorInfo(authorName: String): AuthorWikiInfo = withContext(Dispatchers.IO) {
        val trimmed = authorName.trim()
        if (trimmed.length < 2) return@withContext AuthorWikiInfo(authorName = trimmed)
        cache[trimmed]?.let { return@withContext it }

        val candidates = buildCandidateQueries(trimmed)
        var bestMatch: AuthorWikiInfo? = null

        for (candidate in candidates) {
            val arMatch = queryWiki(arApi, displayName = trimmed, queryName = candidate, langPrefix = "ar")
            if (arMatch != null) {
                if (!arMatch.imageUrl.isNullOrBlank()) {
                    bestMatch = arMatch
                    break
                } else if (bestMatch == null) {
                    bestMatch = arMatch
                }
            }
            val enMatch = queryWiki(enApi, displayName = trimmed, queryName = candidate, langPrefix = "en")
            if (enMatch != null) {
                if (!enMatch.imageUrl.isNullOrBlank()) {
                    bestMatch = enMatch
                    break
                } else if (bestMatch == null) {
                    bestMatch = enMatch
                }
            }
        }

        val info = bestMatch ?: AuthorWikiInfo(authorName = trimmed, isVerified = false)
        cache[trimmed] = info
        info
    }

    private fun buildCandidateQueries(raw: String): List<String> {
        val cleaned = raw
            .removePrefix("الإمام ")
            .removePrefix("الشيخ ")
            .removePrefix("الدكتور ")
            .removePrefix("الشاعر ")
            .removePrefix("الأديب ")
            .trim()
        val alias = KNOWN_AUTHOR_ALIASES[raw] ?: KNOWN_AUTHOR_ALIASES[cleaned]
        return listOfNotNull(alias, raw, cleaned.takeIf { it != raw && it.length >= 2 }).distinct()
    }

    private suspend fun queryWiki(
        api: WikipediaRestApi,
        displayName: String,
        queryName: String,
        langPrefix: String
    ): AuthorWikiInfo? {
        val direct = runCatching {
            api.getSummary(queryName.replace(' ', '_'))
        }.getOrNull()?.takeIf { !it.title.isNullOrBlank() && it.type != "disambiguation" }

        val summary = if (direct != null && (!direct.thumbnail?.source.isNullOrBlank() || !direct.originalimage?.source.isNullOrBlank())) {
            direct
        } else {
            val hits = runCatching {
                api.searchTitle(queryName).query?.search.orEmpty()
            }.getOrDefault(emptyList())

            val hitSummaries = hits.mapNotNull { hit ->
                val hitTitle = hit.title ?: return@mapNotNull null
                runCatching { api.getSummary(hitTitle.replace(' ', '_')) }.getOrNull()
                    ?.takeIf { !it.title.isNullOrBlank() && it.type != "disambiguation" }
            }

            hitSummaries.firstOrNull {
                !it.thumbnail?.source.isNullOrBlank() || !it.originalimage?.source.isNullOrBlank()
            } ?: direct ?: hitSummaries.firstOrNull() ?: return null
        }

        val pageUrl = summary.contentUrls?.desktop?.page
            ?: "https://$langPrefix.wikipedia.org/wiki/${URLEncoder.encode(summary.title ?: queryName, "UTF-8")}"
        val imageUrl = summary.thumbnail?.source ?: summary.originalimage?.source

        return AuthorWikiInfo(
            authorName = displayName,
            imageUrl = imageUrl,
            wikipediaUrl = pageUrl,
            description = summary.description,
            isVerified = true
        )
    }

    private companion object {
        val KNOWN_AUTHOR_ALIASES = mapOf(
            "المتنبي" to "أبو الطيب المتنبي",
            "الشافعي" to "محمد بن إدريس الشافعي",
            "الإمام الشافعي" to "محمد بن إدريس الشافعي",
            "الرومي" to "جلال الدين الرومي",
            "جبران" to "جبران خليل جبران",
            "درويش" to "محمود درويش",
            "محفوظ" to "نجيب محفوظ",
            "الرافعي" to "مصطفى صادق الرافعي",
            "ابن القيم" to "ابن قيم الجوزية",
            "الغزالي" to "أبو حامد الغزالي",
            "دوستويفسكي" to "فيودور دوستويفسكي",
            "شكسبير" to "وليم شكسبير",
            "تولستوي" to "ليو تولستوي",
            "أينشتاين" to "ألبرت أينشتاين",
            "سقراط" to "سقراط",
            "أفلاطون" to "أفلاطون",
            "أرسطو" to "أرسطو"
        )
    }
}
