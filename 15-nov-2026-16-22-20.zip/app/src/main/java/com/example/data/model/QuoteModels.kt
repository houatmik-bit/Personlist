package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class QuoteTopic(
    val labelAr: String,
    val lightAccent: Color,
    val darkAccent: Color,
    val containerLight: Color,
    val containerDark: Color
) {
    WISDOM(
        labelAr = "حكمة",
        lightAccent = Color(0xFFB5851D),
        darkAccent = Color(0xFFE8C067),
        containerLight = Color(0xFFF9EED2),
        containerDark = Color(0xFF3A2D12)
    ),
    LOVE(
        labelAr = "حب",
        lightAccent = Color(0xFF8C1D3B),
        darkAccent = Color(0xFFF08CA5),
        containerLight = Color(0xFFF9E1E8),
        containerDark = Color(0xFF3F1623)
    ),
    SUCCESS(
        labelAr = "نجاح",
        lightAccent = Color(0xFF1F6E52),
        darkAccent = Color(0xFF6CD3AA),
        containerLight = Color(0xFFDFF4EB),
        containerDark = Color(0xFF133629)
    ),
    PATIENCE(
        labelAr = "صبر",
        lightAccent = Color(0xFF2E5D7B),
        darkAccent = Color(0xFF7CBCE3),
        containerLight = Color(0xFFE1EFF8),
        containerDark = Color(0xFF162C3B)
    ),
    LITERATURE(
        labelAr = "أدب",
        lightAccent = Color(0xFF6B3E7E),
        darkAccent = Color(0xFFC99AE0),
        containerLight = Color(0xFFF1E6F7),
        containerDark = Color(0xFF2F1D38)
    ),
    HOPE(
        labelAr = "أمل",
        lightAccent = Color(0xFFC05A2B),
        darkAccent = Color(0xFFF29C72),
        containerLight = Color(0xFFFBE8DE),
        containerDark = Color(0xFF3D1F12)
    ),
    CONTEMPLATION(
        labelAr = "تأمل",
        lightAccent = Color(0xFF4B6043),
        darkAccent = Color(0xFF9EC48F),
        containerLight = Color(0xFFE8F1E4),
        containerDark = Color(0xFF1F2B1B)
    );

    companion object {
        fun fromLabel(label: String): QuoteTopic =
            entries.firstOrNull { it.labelAr == label } ?: WISDOM
    }
}

object QuoteStatus {
    const val APPROVED = "approved"
    const val PENDING = "pending"
    const val REJECTED = "rejected"
}

object ReportStatus {
    const val OPEN = "open"
    const val RESOLVED = "resolved"
    const val DISMISSED = "dismissed"
}

object AdminConfig {
    const val OWNER_EMAIL = "khaledhouatmi17@gmail.com"
}

@IgnoreExtraProperties
data class Quote(
    @DocumentId val id: String = "",
    val text: String = "",
    val authorName: String = "",
    val topic: String = QuoteTopic.WISDOM.labelAr,
    val source: String = "",
    val authorImageUrl: String = "",
    val wikipediaUrl: String = "",
    val isAuthorVerified: Boolean = false,
    val isOwnerQuote: Boolean = false,
    val status: String = QuoteStatus.APPROVED,
    val submittedByUid: String = "",
    val submittedByName: String = "",
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val sharedAt: Timestamp?
        get() = createdAt
}

@IgnoreExtraProperties
data class QuoteComment(
    @DocumentId val id: String = "",
    val quoteId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val text: String = "",
    val isPublic: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FavoriteQuote(
    @DocumentId val id: String = "",
    val quoteId: String = "",
    val userId: String = "",
    val text: String = "",
    val authorName: String = "",
    val topic: String = QuoteTopic.WISDOM.labelAr,
    val authorImageUrl: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class LikedQuote(
    @DocumentId val id: String = "",
    val quoteId: String = "",
    val userId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Report(
    @DocumentId val id: String = "",
    val targetType: String = "quote",
    val quoteId: String = "",
    val commentId: String = "",
    val targetSnippet: String = "",
    val reason: String = "",
    val reporterUid: String = "",
    val reporterName: String = "",
    val status: String = ReportStatus.OPEN,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class AuthorWikiInfo(
    val authorName: String,
    val imageUrl: String? = null,
    val wikipediaUrl: String? = null,
    val description: String? = null,
    val isVerified: Boolean = false
)

enum class CardExportTemplate(
    val titleAr: String,
    val bgTopHex: Long,
    val bgBottomHex: Long,
    val textHex: Long,
    val accentHex: Long,
    val subTextHex: Long
) {
    CREAM_PARCHMENT(
        titleAr = "رقّ عتيق",
        bgTopHex = 0xFFFBF5E8,
        bgBottomHex = 0xFFF2E5CC,
        textHex = 0xFF2B1B17,
        accentHex = 0xFF7B1E32,
        subTextHex = 0xFF6B5344
    ),
    ROYAL_BURGUNDY(
        titleAr = "عنابي ملكي",
        bgTopHex = 0xFF5D1729,
        bgBottomHex = 0xFF330A15,
        textHex = 0xFFFBF4E6,
        accentHex = 0xFFD9B25F,
        subTextHex = 0xFFE5CE9E
    ),
    MIDNIGHT_GOLD(
        titleAr = "ليل وذهب",
        bgTopHex = 0xFF171820,
        bgBottomHex = 0xFF0D0E13,
        textHex = 0xFFF6EFE0,
        accentHex = 0xFFE2BA64,
        subTextHex = 0xFFB8A98E
    ),
    EMERALD_INK(
        titleAr = "حبر زمردي",
        bgTopHex = 0xFF133A2E,
        bgBottomHex = 0xFF092119,
        textHex = 0xFFF6F2E9,
        accentHex = 0xFFE0BA67,
        subTextHex = 0xFFAEC7BC
    )
}
