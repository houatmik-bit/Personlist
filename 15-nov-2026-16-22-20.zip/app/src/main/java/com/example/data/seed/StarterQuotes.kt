package com.example.data.seed

import com.example.data.model.Quote
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteTopic

object StarterQuotes {
    val curatedOwnerQuotes = listOf(
        Quote(
            text = "لا تبحث عن قيمتك في أعين الناس، بل ابحث عنها في الأثر الذي تتركه في قلوبهم حين تغيب.",
            authorName = "جبران خليل جبران",
            topic = QuoteTopic.WISDOM.labelAr,
            source = "دمعة وابتسامة",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/جبران_خليل_جبران",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "ما تبحث عنه يبحث عنك، وما تزرعه في أرواح الآخرين من نور سيعود إليك أضعافاً مضاعفة.",
            authorName = "جلال الدين الرومي",
            topic = QuoteTopic.CONTEMPLATION.labelAr,
            source = "المثنوي",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/جلال_الدين_الرومي",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "على هذه الأرض ما يستحق الحياة: على هذه الأرض سيدة الأرض، أم البدايات وأم النهايات.",
            authorName = "محمود درويش",
            topic = QuoteTopic.HOPE.labelAr,
            source = "ورد أقل",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/محمود_درويش",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "على قَدرِ أهلِ العَزمِ تأتي العَزائمُ، وتأتي على قَدرِ الكِرامِ المَكارمُ.",
            authorName = "المتنبي",
            topic = QuoteTopic.SUCCESS.labelAr,
            source = "ديوان المتنبي",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/أبو_الطيب_المتنبي",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "إنّ الحبَّ لا يطلب أن يمتلكَ، بل أن يُحرّر الروحَ لتُحلّق في سماواتِ الجمالِ والسكينة.",
            authorName = "نجيب محفوظ",
            topic = QuoteTopic.LOVE.labelAr,
            source = "أصداء السيرة الذاتية",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/نجيب_محفوظ",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "دَعِ الأَيّامَ تَفعَلُ ما تَشاءُ، وَطِب نَفساً إِذا حَكَمَ القَضاءُ.",
            authorName = "الإمام الشافعي",
            topic = QuoteTopic.PATIENCE.labelAr,
            source = "ديوان الشافعي",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/الشافعي",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "كُن جميلاً ترَ الوجودَ جميلاً، والذي نفسُهُ بغيرِ جمالٍ لا يرى في الوجودِ شيئاً جميلاً.",
            authorName = "إيليا أبو ماضي",
            topic = QuoteTopic.LITERATURE.labelAr,
            source = "الجداول",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/إيليا_أبو_ماضي",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        ),
        Quote(
            text = "الأشياء العظيمة لا تُبنى بالصخب، بل بالصبر الهادئ واليقين الذي لا تهزّه العواصف.",
            authorName = "غسان كنفاني",
            topic = QuoteTopic.PATIENCE.labelAr,
            source = "أدب المقاومة",
            wikipediaUrl = "https://ar.wikipedia.org/wiki/غسان_كنفاني",
            isAuthorVerified = true,
            isOwnerQuote = true,
            status = QuoteStatus.APPROVED
        )
    )
}
