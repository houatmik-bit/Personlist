package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Quote
import com.example.data.model.QuoteStatus
import com.example.data.model.QuoteTopic
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class AtharRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun submitQuote_visitor_createsPendingQuoteAndAppearsInMySubmissions() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = AtharRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.submitQuote(
                text = "إنما الأثر الطيب يبقى وإن رحل صاحبه.",
                authorName = "جبران خليل جبران",
                topic = QuoteTopic.WISDOM,
                source = "الأجنحة المتكسرة",
                authorImageUrl = null,
                wikipediaUrl = "https://ar.wikipedia.org/wiki/جبران_خليل_جبران",
                isAuthorVerified = true,
                publishImmediatelyAsOwner = true // Visitor should still be forced to pending
            )
        }
        assertTrue(result.isSuccess)
        val quoteId = result.getOrThrow()
        assertTrue(quoteId.isNotBlank())

        val submissions = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMySubmissions(uid).first { list -> list.any { it.id == quoteId } }
        }
        val created = submissions.first { it.id == quoteId }
        assertEquals(QuoteStatus.PENDING, created.status)
        assertEquals(false, created.isOwnerQuote)
    }

    @Test
    fun submitQuote_visitorDirectApprovedWrite_failsWithPermissionDenied() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val quoteId = "bypass_${UUID.randomUUID()}"
        var caught: FirebaseFirestoreException? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection(AtharRepository.QUOTES_COLLECTION).document(quoteId).set(
                    mapOf(
                        "text" to "محاولة نشر مباشر دون موافقة.",
                        "authorName" to "كاتب ما",
                        "topic" to QuoteTopic.WISDOM.labelAr,
                        "isAuthorVerified" to false,
                        "isOwnerQuote" to false,
                        "status" to QuoteStatus.APPROVED,
                        "submittedByUid" to uid,
                        "submittedByName" to "أليس",
                        "likesCount" to 0L,
                        "commentsCount" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: Exception) {
            caught = e.unwrapFirestoreException()
        }
        assertNotNull(caught)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, caught?.code)
    }

    @Test
    fun observeApprovedQuotes_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = AtharRepository(firestore, auth)

        var caught: Exception? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeApprovedQuotes().first()
            }
        } catch (e: Exception) {
            caught = e
        }
        assertNotNull(caught)
        // Repository fail-fast requireUserId throws IllegalStateException when auth.currentUser == null
        assertTrue(caught is IllegalStateException || caught?.unwrapFirestoreException()?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    @Test
    fun directFirestoreQuery_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        var caught: FirebaseFirestoreException? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection(AtharRepository.QUOTES_COLLECTION)
                    .whereEqualTo("status", QuoteStatus.APPROVED)
                    .get()
                    .await()
            }
        } catch (e: Exception) {
            caught = e.unwrapFirestoreException()
        }
        assertNotNull(caught)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, caught?.code)
    }

    @Test
    fun toggleFavorite_and_submitReport_succeedForAuthenticatedUser() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = AtharRepository(firestore, auth)
        val fakeQuote = Quote(
            id = "quote_${UUID.randomUUID()}",
            text = "الأمل هو الحلم الذي يوقظ القلوب.",
            authorName = "محمود درويش",
            topic = QuoteTopic.HOPE.labelAr
        )

        val favAdd = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.toggleFavorite(fakeQuote, currentlyFavorited = false)
        }
        assertTrue(favAdd.isSuccess)

        val favs = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeFavorites(uid).first { list -> list.any { it.quoteId == fakeQuote.id } }
        }
        assertTrue(favs.any { it.quoteId == fakeQuote.id })

        val favRemove = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.toggleFavorite(fakeQuote, currentlyFavorited = true)
        }
        assertTrue(favRemove.isSuccess)

        val reportResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.submitReport(
                targetType = "quote",
                quoteId = fakeQuote.id,
                targetSnippet = fakeQuote.text,
                reason = "بلاغ اختباري للتحقق من القواعد"
            )
        }
        assertTrue(reportResult.isSuccess)
    }

    @Test
    fun crossUserFavoriteAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = AtharRepository(firestore, auth)
        val quote = Quote(
            id = "quote_${UUID.randomUUID()}",
            text = "الصبر مفتاح الفرج.",
            authorName = "الإمام الشافعي",
            topic = QuoteTopic.PATIENCE.labelAr
        )
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.toggleFavorite(quote, currentlyFavorited = false).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        var caught: FirebaseFirestoreException? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection(AtharRepository.USERS_COLLECTION)
                    .document(aliceUid)
                    .collection(AtharRepository.FAVORITES_COLLECTION)
                    .get()
                    .await()
            }
        } catch (e: Exception) {
            caught = e.unwrapFirestoreException()
        }
        assertNotNull(caught)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, caught?.code)
    }

    @Test
    fun quoteCrud_createReadUpdateDeletePendingQuote_succeedsForOwner() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = AtharRepository(firestore, auth)

        // Create
        val quoteId = withTimeout(CRUD_TIMEOUT_MS) {
            repository.createQuote(
                text = "اقتباس أولي قابل للتعديل.",
                authorName = "جبران خليل جبران",
                topic = QuoteTopic.WISDOM,
                source = "الأجنحة المتكسرة"
            ).getOrThrow()
        }

        // Read
        val fetched = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getQuoteById(quoteId).getOrThrow()
        }
        assertNotNull(fetched)
        assertEquals("اقتباس أولي قابل للتعديل.", fetched?.text)
        assertNotNull(fetched?.sharedAt)

        // Update pending quote by original submitter
        val updateResult = withTimeout(CRUD_TIMEOUT_MS) {
            repository.updateQuote(
                quoteId = quoteId,
                text = "اقتباس محدّث بعد المراجعة الذاتية.",
                authorName = "جبران خليل جبران",
                topic = QuoteTopic.LITERATURE,
                source = "النبي"
            )
        }
        assertTrue(updateResult.isSuccess)

        val updated = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getQuoteById(quoteId).getOrThrow()
        }
        assertEquals("اقتباس محدّث بعد المراجعة الذاتية.", updated?.text)
        assertEquals(QuoteTopic.LITERATURE.labelAr, updated?.topic)

        // Delete pending quote by original submitter
        val deleteResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.deleteQuote(quoteId)
        }
        assertTrue(deleteResult.isSuccess)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_athar@test.com"
        const val BOB_EMAIL = "bob_athar@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val CRUD_TIMEOUT_MS = 10000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
